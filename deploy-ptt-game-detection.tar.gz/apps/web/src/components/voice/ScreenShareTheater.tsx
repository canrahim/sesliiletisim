import React, { useEffect, useRef, useState } from 'react';
import { Monitor, Users, X, Maximize2, Volume2, Mic, MicOff, Grid, Columns } from 'lucide-react';

interface Participant {
  userId: string;
  username: string;
  stream?: MediaStream;
  isScreenSharing?: boolean;
  isVideoOn?: boolean;
  isMuted?: boolean;
  isSpeaking?: boolean;
}

interface ScreenShareTheaterProps {
  presenter: Participant;
  participants: Participant[];
  onClose: () => void;
  myUserId: string;
}

export const ScreenShareTheater: React.FC<ScreenShareTheaterProps> = ({
  presenter,
  participants,
  onClose,
  myUserId,
}) => {
  const mainVideoRef = useRef<HTMLVideoElement>(null);
  const [showParticipants, setShowParticipants] = useState(true);
  const [layout, setLayout] = useState<'sidebar' | 'grid'>('sidebar');

  useEffect(() => {
    if (mainVideoRef.current && presenter.stream) {
      mainVideoRef.current.srcObject = presenter.stream;
    }
  }, [presenter.stream]);

  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-neutral-900 to-neutral-800 px-6 py-4 flex items-center justify-between border-b-2 border-neutral-700">
        <div className="flex items-center gap-4">
          <Monitor className="w-6 h-6 text-green-400" />
          <div>
            <p className="text-white font-bold text-lg">
              {presenter.username} ekran paylaşıyor
            </p>
            <p className="text-neutral-400 text-sm">
              {participants.length} katılımcı
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Layout Toggle */}
          <button
            onClick={() => setLayout(layout === 'sidebar' ? 'grid' : 'sidebar')}
            className="px-4 py-2 bg-neutral-700 hover:bg-neutral-600 text-white rounded-xl transition-all flex items-center gap-2"
            title={layout === 'sidebar' ? 'Grid View' : 'Sidebar View'}
          >
            {layout === 'sidebar' ? <Grid className="w-4 h-4" /> : <Columns className="w-4 h-4" />}
            <span className="text-sm">{layout === 'sidebar' ? 'Grid' : 'Kenar Çubuğu'}</span>
          </button>

          {/* Participants Toggle */}
          <button
            onClick={() => setShowParticipants(!showParticipants)}
            className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
              showParticipants 
                ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                : 'bg-neutral-700 hover:bg-neutral-600 text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span className="text-sm">{participants.length}</span>
          </button>

          {/* Close */}
          <button
            onClick={onClose}
            className="p-3 bg-red-600 hover:bg-red-700 text-white rounded-xl transition-all"
            title="Kapat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Main Screen Share */}
        <div className={`flex-1 flex items-center justify-center bg-neutral-950 p-4 ${
          layout === 'grid' ? 'hidden' : ''
        }`}>
          <video
            ref={mainVideoRef}
            autoPlay
            playsInline
            muted
            className="max-w-full max-h-full object-contain rounded-xl shadow-2xl"
          />
        </div>

        {/* Grid Layout (All participants equally) */}
        {layout === 'grid' && (
          <div className="flex-1 grid grid-cols-2 lg:grid-cols-3 gap-4 p-4 bg-neutral-950 overflow-y-auto">
            {/* Presenter (larger) */}
            <div className="col-span-2 lg:col-span-3 bg-neutral-900 rounded-xl overflow-hidden relative aspect-video">
              <video
                ref={mainVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-contain"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center text-white font-bold">
                    {presenter.username.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-white font-bold">{presenter.username}</p>
                    <div className="flex items-center gap-2">
                      <Monitor className="w-4 h-4 text-green-400" />
                      <span className="text-green-400 text-sm font-semibold">Ekran Paylaşıyor</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Participants */}
            {participants.map((p) => (
              <ParticipantTile key={p.userId} participant={p} isMe={p.userId === myUserId} />
            ))}
          </div>
        )}

        {/* Sidebar - Participants */}
        {showParticipants && layout === 'sidebar' && (
          <div className="w-80 bg-neutral-900 border-l-2 border-neutral-700 flex flex-col">
            <div className="p-4 border-b border-neutral-700">
              <h3 className="text-white font-bold flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-400" />
                Katılımcılar ({participants.length})
              </h3>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {participants.map((p) => (
                <ParticipantCard key={p.userId} participant={p} isMe={p.userId === myUserId} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Controls */}
      <div className="bg-neutral-900 px-6 py-4 border-t-2 border-neutral-700">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-4">
          <div className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-white" />
            <span className="text-white text-sm">
              Ses: {participants.filter(p => !p.isMuted).length}/{participants.length}
            </span>
          </div>
          
          <div className="h-6 w-px bg-neutral-700"></div>
          
          <div className="flex items-center gap-2">
            <Monitor className="w-5 h-5 text-green-400" />
            <span className="text-white text-sm">
              Ekran: {participants.filter(p => p.isScreenSharing).length}
            </span>
          </div>
          
          <div className="h-6 w-px bg-neutral-700"></div>
          
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-400" />
            <span className="text-white text-sm">
              Video: {participants.filter(p => p.isVideoOn).length}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

// Participant Card (Sidebar)
const ParticipantCard: React.FC<{ participant: Participant; isMe: boolean }> = ({ participant, isMe }) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && participant.stream) {
      videoRef.current.srcObject = participant.stream;
    }
  }, [participant.stream]);

  return (
    <div className={`bg-neutral-800 rounded-xl p-3 border-2 ${
      participant.isSpeaking 
        ? 'border-green-500 shadow-lg shadow-green-500/50' 
        : 'border-neutral-700'
    }`}>
      <div className="flex items-center gap-3">
        <div className={`w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold ${
          participant.isSpeaking ? 'ring-4 ring-green-400 animate-pulse' : ''
        }`}>
          {participant.username.charAt(0).toUpperCase()}
        </div>
        
        <div className="flex-1">
          <p className="text-white font-semibold">
            {participant.username}
            {isMe && <span className="text-xs text-blue-400 ml-2">(Sen)</span>}
          </p>
          <div className="flex items-center gap-2 mt-1">
            {participant.isMuted ? (
              <MicOff className="w-3 h-3 text-red-400" />
            ) : (
              <Mic className="w-3 h-3 text-green-400" />
            )}
            {participant.isVideoOn && <span className="text-xs text-blue-400">📹 Video</span>}
          </div>
        </div>
      </div>

      {/* Video thumbnail if available */}
      {participant.isVideoOn && participant.stream && (
        <div className="mt-2 rounded-lg overflow-hidden bg-black">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full aspect-video object-cover"
          />
        </div>
      )}
    </div>
  );
};

// Participant Tile (Grid)
const ParticipantTile: React.FC<{ participant: Participant; isMe: boolean }> = ({ participant, isMe }) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && participant.stream) {
      videoRef.current.srcObject = participant.stream;
    }
  }, [participant.stream]);

  const hasMedia = participant.isVideoOn || participant.isScreenSharing;

  return (
    <div className={`bg-neutral-900 rounded-xl overflow-hidden relative aspect-video border-2 ${
      participant.isSpeaking 
        ? 'border-green-500 shadow-lg shadow-green-500/50' 
        : 'border-neutral-700'
    }`}>
      {hasMedia ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center">
          <div className={`w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-3xl ${
            participant.isSpeaking ? 'ring-8 ring-green-400 animate-pulse' : ''
          }`}>
            {participant.username.charAt(0).toUpperCase()}
          </div>
        </div>
      )}

      {/* Overlay */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-3">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-white font-semibold text-sm">
              {participant.username}
              {isMe && <span className="text-xs text-blue-400 ml-1">(Sen)</span>}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {participant.isMuted ? (
              <MicOff className="w-4 h-4 text-red-400" />
            ) : (
              <Mic className="w-4 h-4 text-green-400" />
            )}
          </div>
        </div>
      </div>

      {/* Speaking indicator */}
      {participant.isSpeaking && (
        <div className="absolute top-3 right-3 flex gap-1">
          <div className="w-1 h-4 bg-green-400 rounded-full animate-bounce"></div>
          <div className="w-1 h-6 bg-green-400 rounded-full animate-bounce" style={{animationDelay: '100ms'}}></div>
          <div className="w-1 h-4 bg-green-400 rounded-full animate-bounce" style={{animationDelay: '200ms'}}></div>
        </div>
      )}
    </div>
  );
};


