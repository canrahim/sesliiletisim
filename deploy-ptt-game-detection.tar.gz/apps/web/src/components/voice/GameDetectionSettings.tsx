// apps/web/src/components/voice/GameDetectionSettings.tsx

import React, { useState, useEffect } from 'react';
import { Gamepad2, Plus, Trash2, RefreshCw, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

declare global {
  interface Window {
    electron?: {
      invoke: (channel: string, ...args: any[]) => Promise<any>;
      on: (channel: string, callback: (...args: any[]) => void) => void;
      removeListener: (channel: string, callback: (...args: any[]) => void) => void;
    };
  }
}

interface GameInfo {
  processName: string;
  displayName: string;
  pid: number;
  windowTitle?: string;
  isFullScreen: boolean;
}

interface GameDetectorConfig {
  enabled: boolean;
  checkInterval: number;
  knownGames: string[];
  autoEnablePTT: boolean;
  fullScreenOnly: boolean;
}

export const GameDetectionSettings: React.FC = () => {
  const [isElectron, setIsElectron] = useState(false);
  const [currentGame, setCurrentGame] = useState<GameInfo | null>(null);
  const [config, setConfig] = useState<GameDetectorConfig | null>(null);
  const [newGameProcess, setNewGameProcess] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Electron kontrolü
    if (window.electron) {
      setIsElectron(true);
      loadConfig();
      checkCurrentGame();

      // Oyun algılama event'leri
      const handleGameDetected = (_: any, game: GameInfo) => {
        setCurrentGame(game);
      };

      const handleGameClosed = () => {
        setCurrentGame(null);
      };

      window.electron.on('game-detected', handleGameDetected);
      window.electron.on('game-closed', handleGameClosed);

      return () => {
        window.electron?.removeListener('game-detected', handleGameDetected);
        window.electron?.removeListener('game-closed', handleGameClosed);
      };
    }
  }, []);

  const loadConfig = async () => {
    if (!window.electron) return;
    
    try {
      const cfg = await window.electron.invoke('get-game-detector-config');
      setConfig(cfg);
    } catch (error) {
      console.error('Failed to load game detector config:', error);
    }
  };

  const checkCurrentGame = async () => {
    if (!window.electron) return;
    
    try {
      const game = await window.electron.invoke('get-current-game');
      setCurrentGame(game);
    } catch (error) {
      console.error('Failed to check current game:', error);
    }
  };

  const updateConfig = async (updates: Partial<GameDetectorConfig>) => {
    if (!window.electron || !config) return;

    try {
      await window.electron.invoke('update-game-detector-config', updates);
      setConfig({ ...config, ...updates });
    } catch (error) {
      console.error('Failed to update config:', error);
    }
  };

  const addGame = async () => {
    if (!window.electron || !newGameProcess.trim()) return;

    try {
      await window.electron.invoke('add-game', newGameProcess.trim());
      await loadConfig();
      setNewGameProcess('');
    } catch (error) {
      console.error('Failed to add game:', error);
    }
  };

  const removeGame = async (processName: string) => {
    if (!window.electron) return;

    try {
      await window.electron.invoke('remove-game', processName);
      await loadConfig();
    } catch (error) {
      console.error('Failed to remove game:', error);
    }
  };

  const checkNow = async () => {
    if (!window.electron) return;
    
    setLoading(true);
    try {
      const game = await window.electron.invoke('check-game-now');
      setCurrentGame(game);
    } catch (error) {
      console.error('Failed to check game:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!isElectron) {
    return (
      <div className="p-4 bg-yellow-900/20 border border-yellow-700 rounded-lg">
        <div className="flex items-center gap-2 text-yellow-400">
          <AlertCircle className="w-5 h-5" />
          <p className="text-sm">
            Oyun algılama özelliği sadece desktop uygulamasında kullanılabilir.
          </p>
        </div>
      </div>
    );
  }

  if (!config) {
    return (
      <div className="p-4 text-center text-gray-400">
        <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
        <p>Yükleniyor...</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 p-4 bg-gray-800 rounded-lg">
      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
        <Gamepad2 className="w-5 h-5" />
        Oyun Algılama
      </h3>

      {/* Mevcut Oyun Durumu */}
      <div className="p-4 bg-gray-700 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-sm font-medium text-gray-300">Oyun Durumu</h4>
          <button
            onClick={checkNow}
            disabled={loading}
            className="p-2 bg-gray-600 hover:bg-gray-500 rounded-md transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 text-white ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
        
        {currentGame ? (
          <div className="flex items-center gap-3 p-3 bg-green-900/30 border border-green-700 rounded-md">
            <CheckCircle className="w-5 h-5 text-green-400" />
            <div className="flex-1">
              <p className="text-white font-medium">{currentGame.displayName}</p>
              <p className="text-xs text-gray-400">{currentGame.processName}</p>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3 p-3 bg-gray-600 rounded-md">
            <XCircle className="w-5 h-5 text-gray-400" />
            <p className="text-gray-300 text-sm">Oyun algılanmadı</p>
          </div>
        )}
      </div>

      {/* Ayarlar */}
      <div className="space-y-3">
        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={config.enabled}
            onChange={(e) => updateConfig({ enabled: e.target.checked })}
            className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
          />
          <span className="text-white">Oyun algılamayı etkinleştir</span>
        </label>

        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={config.autoEnablePTT}
            onChange={(e) => updateConfig({ autoEnablePTT: e.target.checked })}
            disabled={!config.enabled}
            className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 disabled:opacity-50"
          />
          <span className={`${config.enabled ? 'text-white' : 'text-gray-500'}`}>
            Oyun algılandığında PTT'yi otomatik aktif et
          </span>
        </label>

        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={config.fullScreenOnly}
            onChange={(e) => updateConfig({ fullScreenOnly: e.target.checked })}
            disabled={!config.enabled}
            className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 disabled:opacity-50"
          />
          <span className={`${config.enabled ? 'text-white' : 'text-gray-500'}`}>
            Sadece tam ekran oyunları algıla
          </span>
        </label>
      </div>

      {/* Kontrol Aralığı */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-300 flex items-center justify-between">
          <span>Kontrol Aralığı</span>
          <span className="text-xs text-gray-400">{config.checkInterval / 1000}s</span>
        </label>
        <input
          type="range"
          min="1000"
          max="10000"
          step="1000"
          value={config.checkInterval}
          onChange={(e) => updateConfig({ checkInterval: Number(e.target.value) })}
          disabled={!config.enabled}
          className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer disabled:opacity-50"
        />
        <p className="text-xs text-gray-400">
          Oyun kontrolünün ne sıklıkla yapılacağını belirler
        </p>
      </div>

      {/* Oyun Listesi */}
      <div className="space-y-2">
        <h4 className="text-sm font-medium text-gray-300">Bilinen Oyunlar ({config.knownGames.length})</h4>
        
        {/* Yeni Oyun Ekle */}
        <div className="flex gap-2">
          <input
            type="text"
            value={newGameProcess}
            onChange={(e) => setNewGameProcess(e.target.value)}
            placeholder="örn: csgo.exe"
            className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            onKeyPress={(e) => e.key === 'Enter' && addGame()}
          />
          <button
            onClick={addGame}
            disabled={!newGameProcess.trim()}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Oyun Listesi */}
        <div className="max-h-60 overflow-y-auto space-y-1">
          {config.knownGames.slice(0, 20).map((game, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-2 bg-gray-700 rounded-md hover:bg-gray-600 transition-colors"
            >
              <span className="text-sm text-gray-300">{game}</span>
              <button
                onClick={() => removeGame(game)}
                className="p-1 hover:bg-red-600 rounded transition-colors"
              >
                <Trash2 className="w-3 h-3 text-red-400" />
              </button>
            </div>
          ))}
          {config.knownGames.length > 20 && (
            <p className="text-xs text-gray-500 text-center py-2">
              +{config.knownGames.length - 20} daha fazla oyun...
            </p>
          )}
        </div>
      </div>

      {/* Bilgi Notu */}
      <div className="p-3 bg-blue-900/20 border border-blue-700 rounded-md">
        <p className="text-xs text-blue-300">
          💡 <strong>İpucu:</strong> Yeni bir oyun eklemek için oyunun process adını girin (örn: valorant.exe).
          Process adını Task Manager'dan öğrenebilirsiniz.
        </p>
      </div>
    </div>
  );
};

