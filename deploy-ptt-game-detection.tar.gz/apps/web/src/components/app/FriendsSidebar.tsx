import React, { useState, useEffect, useRef } from 'react';
import { Users, UserPlus, Check, X } from 'lucide-react';
import { friendsApi } from '../../api/endpoints/friends';
import { useAuthStore } from '../../store/auth.store';
import { io, Socket } from 'socket.io-client';

interface Friend {
  id: string;
  username: string;
  displayName?: string;
  avatar?: string;
  isOnline: boolean;
}

interface FriendRequest {
  id: string;
  user: Friend;
}

const API_BASE = typeof window !== 'undefined' && window.location.hostname === 'app.asforces.com' 
  ? 'https://asforces.com' 
  : 'http://localhost:3000';

export const FriendsSidebar: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { accessToken } = useAuthStore();
  const [friends, setFriends] = useState<Friend[]>([]);
  const [pendingRequests, setPendingRequests] = useState<FriendRequest[]>([]);
  const [newFriendUsername, setNewFriendUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const presenceSocketRef = useRef<Socket | null>(null);

  useEffect(() => {
    loadFriends();
    loadPendingRequests();
  }, []);

  // Initialize presence socket
  useEffect(() => {
    if (!accessToken) return;

    const presenceSocket = io(`${API_BASE}/presence`, {
      path: '/socket.io',
      auth: { token: accessToken },
      transports: ['websocket', 'polling'],
      withCredentials: true,
    });

    presenceSocketRef.current = presenceSocket;

    presenceSocket.on('connect', () => {
      console.log('✅ Connected to presence gateway (friends sidebar)');
    });

    presenceSocket.on('presence-update', ({ userId, status }: { userId: string; status: string | { isOnline: boolean } }) => {
      const isOnline = typeof status === 'string' ? status === 'online' : status.isOnline;
      
      // Update friend list with new online status
      setFriends(prev => prev.map(friend => 
        friend.id === userId 
          ? { ...friend, isOnline }
          : friend
      ));
    });

    return () => {
      presenceSocket.disconnect();
    };
  }, [accessToken]);

  const loadFriends = async () => {
    try {
      const response = await friendsApi.getAll();
      setFriends(response.data);
    } catch (error) {
      console.error('Error loading friends:', error);
    }
  };

  const loadPendingRequests = async () => {
    try {
      const response = await friendsApi.getPendingRequests();
      setPendingRequests(response.data);
    } catch (error) {
      console.error('Error loading pending requests:', error);
    }
  };

  const sendRequest = async () => {
    if (!newFriendUsername.trim()) return;

    setLoading(true);
    try {
      await friendsApi.sendRequest(newFriendUsername);
      setNewFriendUsername('');
      alert(`Arkadaşlık isteği gönderildi: ${newFriendUsername}`);
    } catch (error: any) {
      alert(error.response?.data?.message || 'İstek gönderilemedi');
    } finally {
      setLoading(false);
    }
  };

  const acceptRequest = async (requestId: string) => {
    try {
      await friendsApi.acceptRequest(requestId);
      loadFriends();
      loadPendingRequests();
    } catch (error) {
      console.error('Error accepting request:', error);
    }
  };

  const declineRequest = async (requestId: string) => {
    try {
      await friendsApi.declineRequest(requestId);
      loadPendingRequests();
    } catch (error) {
      console.error('Error declining request:', error);
    }
  };

  const removeFriend = async (friendId: string) => {
    if (!confirm('Arkadaşlıktan çıkarmak istediğinize emin misiniz?')) return;

    try {
      await friendsApi.removeFriend(friendId);
      loadFriends();
    } catch (error) {
      console.error('Error removing friend:', error);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-4 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Users className="w-6 h-6" />
            <h2 className="text-xl font-bold">Arkadaşlar</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Add Friend */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 mb-3 flex items-center space-x-2">
              <UserPlus className="w-4 h-4" />
              <span>Arkadaş Ekle</span>
            </h3>
            <div className="flex space-x-2">
              <input
                type="text"
                value={newFriendUsername}
                onChange={(e) => setNewFriendUsername(e.target.value)}
                placeholder="Kullanıcı adı..."
                className="flex-1 px-4 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                onKeyPress={(e) => e.key === 'Enter' && sendRequest()}
              />
              <button
                onClick={sendRequest}
                disabled={loading || !newFriendUsername.trim()}
                className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors disabled:opacity-50"
              >
                Gönder
              </button>
            </div>
          </div>

          {/* Pending Requests */}
          {pendingRequests.length > 0 && (
            <div>
              <h3 className="font-semibold text-neutral-700 mb-2">Bekleyen İstekler ({pendingRequests.length})</h3>
              <div className="space-y-2">
                {pendingRequests.map((request) => (
                  <div key={request.id} className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-yellow-600 rounded-full flex items-center justify-center text-white font-bold">
                        {request.user.username?.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium text-neutral-800">
                          {request.user.displayName || request.user.username}
                        </div>
                        <div className="text-sm text-neutral-500">@{request.user.username}</div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => acceptRequest(request.id)}
                        className="p-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                        title="Kabul Et"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => declineRequest(request.id)}
                        className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                        title="Reddet"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Friends List */}
          <div>
            <h3 className="font-semibold text-neutral-700 mb-2">Arkadaşlarım ({friends.length})</h3>
            {friends.length === 0 ? (
              <div className="text-center py-8 text-neutral-500">
                <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Henüz arkadaşınız yok</p>
                <p className="text-sm">Yukarıdan kullanıcı adıyla arkadaş ekleyin!</p>
              </div>
            ) : (
              <div className="space-y-2">
                {friends.map((friend) => (
                  <div key={friend.id} className="flex items-center justify-between p-3 bg-neutral-50 border border-neutral-200 rounded-lg hover:bg-neutral-100 transition-colors">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                          {friend.username?.charAt(0).toUpperCase()}
                        </div>
                        {friend.isOnline && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </div>
                      <div>
                        <div className="font-medium text-neutral-800">
                          {friend.displayName || friend.username}
                        </div>
                        <div className="text-sm text-neutral-500">
                          {friend.isOnline ? '🟢 Çevrimiçi' : '⚫ Çevrimdışı'}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => removeFriend(friend.id)}
                      className="px-3 py-1 bg-red-100 hover:bg-red-200 text-red-700 text-sm font-medium rounded transition-colors"
                    >
                      Kaldır
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

