import React, { useState, useEffect, useRef, useMemo } from 'react';
import { MessageSquare, Send, ArrowLeft, Trash2, Search, X } from 'lucide-react';
import { EmojiPicker } from '../ui/EmojiPicker';
import { FileUpload } from '../ui/FileUpload';
import { uploadApi } from '../../api/endpoints/upload';
import { io, Socket } from 'socket.io-client';
import { useAuthStore } from '../../store/auth.store';
import { friendsApi } from '../../api/endpoints/friends';

interface Friend {
  id: string;
  username: string;
  displayName?: string;
  avatar?: string;
  isOnline: boolean;
}

interface DirectMessage {
  id: string;
  content: string;
  senderId: string;
  receiverId: string;
  createdAt: string;
  sender: {
    id: string;
    username: string;
    displayName?: string;
    avatar?: string;
  };
}

const API_BASE = typeof window !== 'undefined' && window.location.hostname === 'app.asforces.com' 
  ? 'https://asforces.com' 
  : 'http://localhost:3000';

interface DirectMessagesViewProps {
  showToast: (type: 'success' | 'error' | 'info' | 'warning', message: string) => void;
}

export const DirectMessagesView: React.FC<DirectMessagesViewProps> = ({ showToast }) => {
  const { user, accessToken } = useAuthStore();
  const [friends, setFriends] = useState<Friend[]>([]);
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null);
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  const socketRef = useRef<Socket | null>(null);
  const presenceSocketRef = useRef<Socket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Filter friends based on search query
  const filteredFriends = useMemo(() => {
    if (!searchQuery.trim()) return friends;
    
    const query = searchQuery.toLowerCase();
    return friends.filter(friend => 
      friend.username.toLowerCase().includes(query) ||
      friend.displayName?.toLowerCase().includes(query)
    );
  }, [friends, searchQuery]);

  useEffect(() => {
    loadFriends();
  }, []);

  // Initialize DM socket
  useEffect(() => {
    if (!accessToken) return;

    const dmSocket = io(`${API_BASE}/dm`, {
      auth: { token: accessToken },
      transports: ['websocket', 'polling'],
      withCredentials: true,
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 2000,
    });

    socketRef.current = dmSocket;

    dmSocket.on('connect', () => {
      console.log('✅ Connected to DM gateway');
    });

    dmSocket.on('new-dm', (dm: DirectMessage) => {
      console.log('📨 New DM received:', dm);
      // If viewing conversation with sender, add message
      if (selectedFriend && (dm.senderId === selectedFriend.id || dm.receiverId === selectedFriend.id)) {
        setMessages(prev => [...prev, dm]);
        scrollToBottom();
      }
    });

    dmSocket.on('connect_error', (error) => {
      console.error('❌ DM connection error:', error);
    });

    return () => {
      dmSocket.disconnect();
    };
  }, [accessToken, selectedFriend]);

  // Initialize presence socket for real-time online status
  useEffect(() => {
    if (!accessToken) return;

    const presenceSocket = io(`${API_BASE}/presence`, {
      auth: { token: accessToken },
      transports: ['websocket', 'polling'],
      withCredentials: true,
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 2000,
    });

    presenceSocketRef.current = presenceSocket;

    presenceSocket.on('connect', () => {
      // Silent connection - no spam
    });

    presenceSocket.on('presence-update', ({ userId, status }: { userId: string; status: string | { isOnline: boolean } }) => {
      // Silent update - no spam
      const isOnline = typeof status === 'string' ? status === 'online' : status.isOnline;
      
      // Update friends list with new online status
      setFriends(prev => prev.map(friend => 
        friend.id === userId 
          ? { ...friend, isOnline }
          : friend
      ));
      // Update selected friend status
      setSelectedFriend(prev => 
        prev && prev.id === userId 
          ? { ...prev, isOnline }
          : prev
      );
    });

    return () => {
      presenceSocket.disconnect();
    };
  }, [accessToken]);

  const loadFriends = async () => {
    try {
      const response = await friendsApi.getAll();
      setFriends(response.data);
    } catch (error) {
      console.error('Error loading friends:', error);
    }
  };

  const loadConversation = async (friendId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/dm/${friendId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
        credentials: 'include',
      });
      
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
        setTimeout(scrollToBottom, 100);
      }
    } catch (error) {
      console.error('Error loading conversation:', error);
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!newMessage.trim() && !selectedFile) || !selectedFriend) return;

    const messageContent = newMessage;
    const fileToUpload = selectedFile;
    setNewMessage('');
    setSelectedFile(null);

    try {
      let fileData = null;
      
      // Dosya varsa gerçek upload
      if (fileToUpload) {
        setIsUploading(true);
        const uploadResponse = await uploadApi.uploadFile(fileToUpload, (progress) => {
          // Progress tracking
        });
        fileData = uploadResponse.data;
        setIsUploading(false);
      }

      const finalContent = messageContent || (fileData ? `📎 ${fileData.filename}` : '');
      
      const response = await fetch(`${API_BASE}/api/dm/${selectedFriend.id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        credentials: 'include',
        body: JSON.stringify({ content: finalContent }),
      });

      if (response.ok) {
        const dm = await response.json();
        setMessages(prev => [...prev, dm]);
        scrollToBottom();
        
        if (fileData) {
          showToast('success', `✅ Dosya yüklendi: ${fileData.filename}`);
        }
      } else {
        setNewMessage(messageContent);
        setSelectedFile(fileToUpload);
        showToast('error', 'Mesaj gönderilemedi');
      }
    } catch (error: any) {
      console.error('Error sending DM:', error);
      setNewMessage(messageContent);
      setSelectedFile(fileToUpload);
      showToast('error', error.response?.data?.message || 'Mesaj gönderilemedi');
    } finally {
      setIsUploading(false);
    }
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  // Auto scroll when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <div className="h-full flex bg-neutral-50">
      {/* Left Sidebar - Friends List - Modern Design */}
      <div className="w-72 bg-white border-r-2 border-neutral-200 flex flex-col shadow-lg">
        <div className="px-6 py-5 bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-md">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-lg">Direkt Mesajlar</h2>
              <p className="text-xs text-blue-100">{friends.length} arkadaş</p>
            </div>
          </div>
          
          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-300" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Arkadaş ara..."
              className="w-full pl-11 pr-10 py-3 bg-white/20 backdrop-blur-sm border-2 border-white/30 rounded-xl text-white placeholder-blue-200 focus:bg-white/30 focus:border-white/50 outline-none transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-white/20 rounded-lg transition-all"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            )}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {filteredFriends.length === 0 ? (
            <div className="text-center py-12 px-4">
              <div className="w-20 h-20 rounded-2xl bg-blue-100 flex items-center justify-center mx-auto mb-4">
                <MessageSquare className="w-10 h-10 text-blue-600" />
              </div>
              <p className="text-neutral-600 font-semibold mb-2">Henüz arkadaşınız yok</p>
              <p className="text-xs text-neutral-500">Arkadaş ekleyerek sohbete başlayın!</p>
            </div>
          ) : searchQuery && filteredFriends.length === 0 ? (
            <div className="text-center py-12 px-4">
              <Search className="w-16 h-16 text-neutral-300 mx-auto mb-3" />
              <p className="text-neutral-600 font-medium">"{searchQuery}" için sonuç bulunamadı</p>
              <button
                onClick={() => setSearchQuery('')}
                className="mt-3 text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                Aramayı Temizle
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredFriends.map((friend) => (
                <button
                  key={friend.id}
                  onClick={() => {
                    setSelectedFriend(friend);
                    loadConversation(friend.id);
                  }}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-200 group ${
                    selectedFriend?.id === friend.id
                      ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg scale-105'
                      : 'hover:bg-blue-50 hover:scale-102'
                  }`}
                >
                  <div className="relative">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-base shadow-md ${
                      selectedFriend?.id === friend.id
                        ? 'bg-white/20 text-white'
                        : 'bg-gradient-to-br from-blue-500 to-blue-600 text-white'
                    }`}>
                      {friend.username?.charAt(0).toUpperCase()}
                    </div>
                    {friend.isOnline && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white shadow-sm"></div>
                    )}
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <div className={`font-bold text-sm truncate ${
                      selectedFriend?.id === friend.id ? 'text-white' : 'text-neutral-800'
                    }`}>
                      {friend.displayName || friend.username}
                    </div>
                    <div className={`text-xs flex items-center gap-1 ${
                      selectedFriend?.id === friend.id ? 'text-blue-100' : 'text-neutral-500'
                    }`}>
                      <div className={`w-2 h-2 rounded-full ${friend.isOnline ? 'bg-green-400' : 'bg-neutral-400'}`}></div>
                      {friend.isOnline ? 'Çevrimiçi' : 'Çevrimdışı'}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right - Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedFriend ? (
          <>
            {/* Chat Header - Premium Design */}
            <div className="h-20 bg-white border-b-2 border-neutral-200 flex items-center justify-between px-6 shadow-sm">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setSelectedFriend(null)}
                  className="p-2 hover:bg-blue-50 rounded-xl transition-all lg:hidden"
                >
                  <ArrowLeft className="w-5 h-5 text-neutral-700" />
                </button>
                <div className="relative">
                  <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-lg">
                    {selectedFriend.username?.charAt(0).toUpperCase()}
                  </div>
                  {selectedFriend.isOnline && (
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-3 border-white shadow-md"></div>
                  )}
                </div>
                <div>
                  <div className="font-bold text-lg text-neutral-900">
                    {selectedFriend.displayName || selectedFriend.username}
                  </div>
                  <div className="flex items-center gap-1.5 text-sm">
                    <div className={`w-2 h-2 rounded-full ${selectedFriend.isOnline ? 'bg-green-500' : 'bg-neutral-400'}`}></div>
                    <span className={`font-medium ${selectedFriend.isOnline ? 'text-green-600' : 'text-neutral-500'}`}>
                      {selectedFriend.isOnline ? 'Çevrimiçi' : 'Çevrimdışı'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-neutral-50">
              {loading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-neutral-500">Yükleniyor...</div>
                </div>
              ) : messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center text-neutral-500">
                    <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>Henüz mesaj yok</p>
                    <p className="text-sm">İlk mesajı siz gönderin!</p>
                  </div>
                </div>
              ) : (
                messages.map((msg) => {
                  const isMe = msg.senderId === user?.id;
                  // Check if message contains invite link
                  const inviteMatch = msg.content.match(/https:\/\/app\.asforces\.com\/invite\/([a-zA-Z0-9]+)/);
                  const inviteCode = inviteMatch ? inviteMatch[1] : null;
                  
                  return (
                    <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} px-4 md:px-12 lg:px-24`}>
                      <div className={`max-w-lg ${isMe ? 'order-2' : 'order-1'}`}>
                        {!isMe && (
                          <div className="text-xs text-neutral-500 mb-1 ml-1">
                            {msg.sender.displayName || msg.sender.username}
                          </div>
                        )}
                        <div className={`inline-block px-4 py-3 rounded-2xl shadow-sm ${
                          isMe 
                            ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-br-md' 
                            : 'bg-white border-2 border-neutral-200 text-neutral-800 rounded-bl-md'
                        }`}>
                          <div className="whitespace-pre-wrap break-words">{msg.content}</div>
                          
                          {/* Invite Link Button */}
                          {inviteCode && (
                            <button
                              onClick={() => {
                                window.location.href = `/invite/${inviteCode}`;
                              }}
                              className={`mt-2 px-4 py-2 rounded-lg font-semibold transition-colors flex items-center space-x-2 ${
                                isMe
                                  ? 'bg-blue-700 hover:bg-blue-800 text-white'
                                  : 'bg-blue-600 hover:bg-blue-700 text-white'
                              }`}
                            >
                              <span>🎉 Sunucuya Katıl</span>
                            </button>
                          )}
                          
                          <div className={`text-xs mt-1 ${isMe ? 'text-blue-100' : 'text-neutral-400'}`}>
                            {new Date(msg.createdAt).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input - Premium Design */}
            <div className="p-6 bg-white border-t-2 border-neutral-200">
              {selectedFile && (
                <div className="mb-3 px-4">
                  <div className="flex items-center gap-3 p-3 bg-blue-50 border-2 border-blue-200 rounded-xl">
                    <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                      <span className="text-2xl">📎</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-neutral-800 truncate">{selectedFile.name}</p>
                      <p className="text-xs text-neutral-600">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                    <button
                      onClick={() => setSelectedFile(null)}
                      className="p-2 hover:bg-red-100 text-red-600 rounded-lg transition-all"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
              
              <form onSubmit={sendMessage} className="flex items-center gap-2 px-4 pb-4">
                {/* Emoji Picker */}
                <EmojiPicker onEmojiSelect={(emoji) => setNewMessage(prev => prev + emoji)} />
                
                {/* File Upload */}
                <FileUpload 
                  onFileSelect={setSelectedFile}
                  onCancel={() => setSelectedFile(null)}
                  selectedFile={selectedFile}
                />
                
                {/* Message Input */}
                <div className="flex-1 bg-neutral-50 rounded-2xl border-2 border-neutral-200 focus-within:border-blue-500 focus-within:bg-white transition-all duration-200 shadow-sm">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder={`${selectedFriend.displayName || selectedFriend.username}'e mesaj gönder...`}
                    className="w-full px-5 py-4 bg-transparent text-neutral-900 placeholder-neutral-500 outline-none font-medium rounded-2xl"
                    disabled={isUploading}
                  />
                </div>
                
                {/* Send Button */}
                <button
                  type="submit"
                  disabled={(!newMessage.trim() && !selectedFile) || isUploading}
                  className="px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:from-neutral-300 disabled:to-neutral-400 text-white rounded-2xl transition-all duration-200 disabled:cursor-not-allowed flex items-center gap-2 font-bold shadow-lg hover:shadow-xl hover:scale-105 disabled:scale-100"
                >
                  {isUploading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span className="hidden sm:inline">Yükleniyor</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      <span className="hidden sm:inline">Gönder</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-neutral-50 to-blue-50">
            <div className="text-center">
              <div className="w-32 h-32 rounded-3xl bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center mx-auto mb-6 shadow-xl">
                <MessageSquare className="w-16 h-16 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-neutral-800 mb-3">Direkt Mesajlar</h3>
              <p className="text-neutral-600 mb-2">Bir arkadaşınızı seçerek sohbete başlayın</p>
              <p className="text-sm text-neutral-500">💬 Özel ve güvenli konuşmalar</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

