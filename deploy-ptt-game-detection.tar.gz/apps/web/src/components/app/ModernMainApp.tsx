import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Settings, Users, LogOut, Link as LinkIcon, Hash, Volume2, Send, Plus, Menu, X, Phone, Mic, MicOff, Monitor, MonitorOff, Video, VideoOff } from 'lucide-react';
import { EmojiPicker } from '../ui/EmojiPicker';
import { FileUpload } from '../ui/FileUpload';
import { io, Socket } from 'socket.io-client';
import { useAuthStore } from '../../store/auth.store';
import { serversApi } from '../../api/endpoints/servers';
import { channelsApi } from '../../api/endpoints/channels';
import { messagesApi } from '../../api/endpoints/messages';
import { uploadApi } from '../../api/endpoints/upload';
import { FriendsSidebar } from './FriendsSidebar';
import { FriendsView } from './FriendsView';
import { DirectMessagesView } from './DirectMessagesView';
import { ToastContainer } from '../ui/Toast';
import { RemoteMediaPanel } from '../voice/RemoteMediaPanel';
import { ScreenShareTheater } from '../voice/ScreenShareTheater';
import { InlineScreenShare } from '../voice/InlineScreenShare';
import { ServerInviteModal } from './ServerInviteModal';
import { CreateChannelModal } from './CreateChannelModal';
import { CreateServerModal } from './CreateServerModal';
import { SettingsModal } from './SettingsModal';

interface Server {
  id: string;
  name: string;
  icon?: string;
}

interface Channel {
  id: string;
  name: string;
  type: 'TEXT' | 'VOICE';
  serverId: string;
}

interface Message {
  id: string;
  content: string;
  userId: string;
  channelId?: string;
  user: {
    username: string;
    displayName?: string;
    avatar?: string;
  };
  createdAt: string;
}

const API_BASE = typeof window !== 'undefined' && window.location.hostname === 'app.asforces.com' 
  ? 'https://asforces.com' 
  : 'http://localhost:3000';

export const ModernMainApp: React.FC = () => {
  const { user, logout, accessToken } = useAuthStore();
  const [view, setView] = useState<'servers' | 'friends' | 'dm'>('servers');
  const [servers, setServers] = useState<Server[]>([]);
  const [selectedServer, setSelectedServer] = useState<Server | null>(null);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showMobileVoice, setShowMobileVoice] = useState(false);
  const [showServerList, setShowServerList] = useState(true);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showFriendsPanel, setShowFriendsPanel] = useState(false);
  const [showDMPanel, setShowDMPanel] = useState(false);
  const [userVolumeSettings, setUserVolumeSettings] = useState<Record<string, number>>({});
  
  // File upload
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  
  // Remote media
  const [remoteUsers, setRemoteUsers] = useState<Array<{ userId: string; username: string; stream?: MediaStream; isScreenSharing?: boolean; isVideoOn?: boolean; isMuted?: boolean; isSpeaking?: boolean }>>([]);
  const [mediaLayout, setMediaLayout] = useState<'grid' | 'speaker'>('grid');
  const [showMediaPanel, setShowMediaPanel] = useState(false);
  const [showTheaterMode, setShowTheaterMode] = useState(false);
  const [theaterPresenter, setTheaterPresenter] = useState<{ userId: string; username: string; stream?: MediaStream } | null>(null);
  const remoteVideoRefs = useRef<Map<string, HTMLVideoElement>>(new Map());
  
  // Voice & Members
  const [connectedVoiceChannelId, setConnectedVoiceChannelId] = useState<string | null>(null);
  const [voiceUsers, setVoiceUsers] = useState<Array<{ userId: string; username: string; isMuted?: boolean; isSpeaking?: boolean }>>([]);
  const [channelVoiceUsers, setChannelVoiceUsers] = useState<Record<string, Array<{ id: string; username: string; isMuted?: boolean }>>>({});
  const [isMuted, setIsMuted] = useState(false);
  const [isDeafened, setIsDeafened] = useState(false);
  const [myAudioLevel, setMyAudioLevel] = useState(0);
  
  // Screen Share & Video states
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(false);
  const [screenQuality, setScreenQuality] = useState<'low' | 'medium' | 'high' | 'ultra'>('medium');
  const [shareSystemAudio, setShareSystemAudio] = useState(false);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const videoStreamRef = useRef<MediaStream | null>(null);
  const [serverMembers, setServerMembers] = useState<Array<{ userId: string; username: string; displayName?: string; isOnline: boolean }>>([]);
  
  // Modals
  const [showNewChannelModal, setShowNewChannelModal] = useState(false);
  const [newChannelName, setNewChannelName] = useState('');
  const [newChannelType, setNewChannelType] = useState<'TEXT' | 'VOICE'>('TEXT');
  const [showNewServerModal, setShowNewServerModal] = useState(false);
  const [newServerName, setNewServerName] = useState('');
  const [newServerDescription, setNewServerDescription] = useState('');
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteCode, setInviteCode] = useState('');
  const [toasts, setToasts] = useState<Array<{ id: string; type: 'success' | 'error' | 'info' | 'warning'; message: string }>>([]);
  
  const socketRef = useRef<Socket | null>(null);
  const voiceSocketRef = useRef<Socket | null>(null);
  const presenceSocketRef = useRef<Socket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const currentChannelIdRef = useRef<string | null>(null);
  const connectedVoiceChannelIdRef = useRef<string | null>(null); // ← YENİ REF!
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioAnalyserRef = useRef<AnalyserNode | null>(null);
  const audioLevelIntervalRef = useRef<number | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const remoteStreamsRef = useRef<Map<string, MediaStream>>(new Map());
  const joinSoundRef = useRef<HTMLAudioElement | null>(null);
  const leaveSoundRef = useRef<HTMLAudioElement | null>(null);
  const isOnlineRef = useRef<boolean>(true);
  const afkTimeoutRef = useRef<number | null>(null);
  const lastActivityRef = useRef<number>(Date.now());

  useEffect(() => { 
    loadServers(); 
    
    // Cleanup on unmount
    return () => {
      console.log('🧹 ModernMainApp unmounting - cleaning up resources');
      
      // Stop audio monitoring
      stopAudioMonitoring();
      
      // Disconnect all sockets
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
      if (voiceSocketRef.current) {
        voiceSocketRef.current.disconnect();
      }
      if (presenceSocketRef.current) {
        presenceSocketRef.current.disconnect();
      }
      
      // Remove all dynamically created audio elements
      document.querySelectorAll('audio[id^="audio-"]').forEach(el => {
        const audioEl = el as HTMLAudioElement;
        audioEl.pause();
        audioEl.srcObject = null;
        audioEl.remove();
      });
    };
  }, []);
  
  useEffect(() => { if (selectedServer) { loadChannels(selectedServer.id); loadServerMembers(selectedServer.id); } }, [selectedServer]);
  
  // AFK Timeout Check (5 dakika - Discord standart)
  useEffect(() => {
    if (!connectedVoiceChannelId) return;
    
    // 5 dakika = 300000 ms
    const AFK_TIMEOUT = 5 * 60 * 1000;
    
    const checkAFK = () => {
      const now = Date.now();
      const timeSinceActivity = now - lastActivityRef.current;
      
      if (timeSinceActivity > AFK_TIMEOUT && connectedVoiceChannelId) {
        console.log('⏰ AFK timeout - Leaving voice channel');
        showToast('warning', '5 dakika boyunca sessiz kaldınız. Sesli kanaldan çıktınız.');
        
        // Kanaldan çık
        stopAudioMonitoring();
        voiceSocketRef.current?.emit('leave-voice');
        setConnectedVoiceChannelId(null);
        connectedVoiceChannelIdRef.current = null;
        setVoiceUsers([]);
        
        // Çıkış sesi
        if (leaveSoundRef.current) {
          leaveSoundRef.current.currentTime = 0;
          leaveSoundRef.current.play().catch(e => console.log('Sound play failed:', e));
        }
      }
    };
    
    // Her dakika kontrol et
    const interval = setInterval(checkAFK, 60000);
    afkTimeoutRef.current = window.setTimeout(() => {}, 0); // Dummy
    
    return () => {
      clearInterval(interval);
      if (afkTimeoutRef.current) clearTimeout(afkTimeoutRef.current);
    };
  }, [connectedVoiceChannelId]);
  
  // Load sound effects
  useEffect(() => {
    joinSoundRef.current = new Audio('/giris_join_long.wav');
    leaveSoundRef.current = new Audio('/cikis_leave_long.wav');
    
    // Online/Offline detection
    const handleOnline = () => {
      console.log('🌐 Internet connection restored');
      isOnlineRef.current = true;
      
      // 💾 Son kanala otomatik katılmayı dene
      try {
        const lastChannel = localStorage.getItem('lastVoiceChannel');
        if (lastChannel) {
          const { channelId, timestamp } = JSON.parse(lastChannel);
          const timePassed = Date.now() - timestamp;
          
          // 5 dakikadan az zaman geçtiyse otomatik katıl
          if (timePassed < 5 * 60 * 1000) {
            showToast('info', 'Sesli kanala yeniden bağlanılıyor...');
            
            // 2 saniye sonra reload (socket'lerin bağlanması için)
            setTimeout(() => {
              window.location.reload();
            }, 2000);
            return;
          }
        }
      } catch (e) {
        console.error('LocalStorage okuma hatası:', e);
      }
      
      // Normal reload
      showToast('success', 'İnternet bağlantısı geri geldi! Sayfa yenileniyor...');
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    };
    
    const handleOffline = () => {
      console.log('⚠️ Internet connection lost');
      isOnlineRef.current = false;
      showToast('error', 'İnternet bağlantısı kesildi! Sayfayı yenileyin.');
      
      // Sesli kanaldan otomatik çık
      if (connectedVoiceChannelIdRef.current) {
        console.log('🚪 Leaving voice channel due to connection loss');
        stopAudioMonitoring();
        setConnectedVoiceChannelId(null);
        connectedVoiceChannelIdRef.current = null;
        setVoiceUsers([]);
        
        // 🔊 ÇIKIŞ SESİ ÇAL!
        if (leaveSoundRef.current) {
          leaveSoundRef.current.currentTime = 0;
          leaveSoundRef.current.play().catch(e => console.log('Sound play failed:', e));
        }
      }
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  
  // Auto-scroll when messages change
  useEffect(() => {
    setTimeout(() => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: 'instant', block: 'end' });
    }
    }, 50); // Small delay to ensure DOM is updated
  }, [messages]);

  // Load messages when channel changes
  useEffect(() => {
    if (!socketRef.current || !selectedChannel || selectedChannel.type !== 'TEXT' || !selectedChannel.id) {
      console.log('⚠️ Invalid channel, skipping');
      return;
    }
    
    // Leave previous channel if exists
    if (currentChannelIdRef.current && currentChannelIdRef.current !== selectedChannel.id) {
      socketRef.current.emit('leave-channel', { channelId: currentChannelIdRef.current });
    }
    
    // Join new channel
    socketRef.current.emit('join-channel', { channelId: selectedChannel.id });
    currentChannelIdRef.current = selectedChannel.id;
    
    // Load messages for new channel
    loadMessages(selectedChannel.id);
  }, [selectedChannel]);

  // WebSocket initialization
  useEffect(() => {
    if (!accessToken) return;
    const socket = io(`${API_BASE}/messages`, {
      auth: { token: accessToken },
      transports: ['websocket'], 
      withCredentials: true,
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000
    });
    socketRef.current = socket;
    socket.on('connect', () => { console.log('✅ Connected'); if (currentChannelIdRef.current) socket.emit('join-channel', { channelId: currentChannelIdRef.current }); });
    socket.on('new-message', (message: Message) => { if (currentChannelIdRef.current === message.channelId) setMessages((prev) => prev.some(m => m.id === message.id) ? prev : [...prev, message]); });
    socket.on('message-deleted', ({ messageId }: { messageId: string }) => setMessages((prev) => prev.filter((m) => m.id !== messageId)));
    return () => { socket.disconnect(); };
  }, [accessToken]);

  // Presence Socket (Silent - no spam!)
  useEffect(() => {
    if (!accessToken || !selectedServer) return;
    const presenceSocket = io(`${API_BASE}/presence`, {
      auth: { token: accessToken },
      transports: ['websocket'], 
      withCredentials: true,
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000
    });
    presenceSocketRef.current = presenceSocket;

    presenceSocket.on('connect', () => {
      // Silent - no console spam
    });

    presenceSocket.on('presence-update', ({ userId, status, isOnline: onlineStatus }: any) => {
      // Handle both old and new format (Silent updates)
      const isOnline = onlineStatus !== undefined 
        ? onlineStatus 
        : (typeof status === 'string' ? status === 'online' : status?.isOnline);
      
      setServerMembers(prev => prev.map(m => 
        m.userId === userId ? { ...m, isOnline } : m
      ));
    });
    
    return () => {
      presenceSocket.disconnect();
    };
  }, [accessToken, selectedServer]);

  // Voice Socket
  useEffect(() => {
    if (!accessToken) return;
    const voiceSocket = io(`${API_BASE}/voice`, { 
      auth: { token: accessToken }, 
      transports: ['websocket'], 
      withCredentials: true,
      reconnection: true,           // ✅ Otomatik yeniden bağlan
      reconnectionAttempts: 10,     // ✅ 10 deneme
      reconnectionDelay: 1000,      // ✅ 1 saniye bekle
      reconnectionDelayMax: 5000,   // ✅ Maks 5 saniye
      timeout: 20000                // ✅ 20 saniye timeout
    });
    voiceSocketRef.current = voiceSocket;
    
    voiceSocket.on('connect', async () => {
      console.log('✅ Voice connected');
      
      // 💾 LocalStorage'dan son kanalı oku
      try {
        const lastChannelData = localStorage.getItem('lastVoiceChannel');
        if (lastChannelData && user) {
          const { channelId, serverId, timestamp } = JSON.parse(lastChannelData);
          const timePassed = Date.now() - timestamp;
          
          // 5 dakikadan az geçtiyse otomatik katıl
          if (timePassed < 5 * 60 * 1000) {
            console.log('🔄 Auto-reconnecting to last voice channel:', channelId);
            
            const server = servers.find(s => s.id === serverId);
            const channel = channels.find(c => c.id === channelId);
            
            if (server && channel) {
              // State'leri ayarla
              setConnectedVoiceChannelId(channelId);
              connectedVoiceChannelIdRef.current = channelId;
              
              // Kendini hemen ekle
              setVoiceUsers([{
                userId: user.id,
                username: user.username,
                isMuted: false,
                isSpeaking: false
              }]);
              
              // Mikrofonu başlat
              const success = await startAudioMonitoring();
              if (!success) {
                console.error('❌ Mikrofon başlatılamadı');
                setConnectedVoiceChannelId(null);
                connectedVoiceChannelIdRef.current = null;
                setVoiceUsers([]);
                localStorage.removeItem('lastVoiceChannel');
                return;
              }
              
              // Sesli kanala katıl
              voiceSocket.emit('join-voice', {
                roomId: serverId,
                channelId: channelId,
                userId: user.id,
                username: user.username
              });
              
              console.log('✅ Auto-reconnected to voice channel');
              showToast('success', 'Sesli kanala yeniden katıldınız!');
              
              // Giriş sesi çal
              setTimeout(() => {
                if (joinSoundRef.current) {
                  joinSoundRef.current.currentTime = 0;
                  joinSoundRef.current.volume = 0.5;
                  joinSoundRef.current.play().catch(e => console.log('Sound failed:', e));
                }
              }, 500);
            } else {
              console.log('⚠️ Last channel not found, clearing localStorage');
              localStorage.removeItem('lastVoiceChannel');
            }
          } else {
            console.log('⏰ Last channel expired (>5 min), clearing');
            localStorage.removeItem('lastVoiceChannel');
          }
        }
      } catch (e) {
        console.error('❌ LocalStorage read error:', e);
      }
    });
    
    voiceSocket.on('disconnect', (reason: string) => {
      console.warn('⚠️ Voice socket disconnected:', reason);
      
      // Bağlantı koparsa peer connections'ı temizle
      peerConnectionsRef.current.forEach((pc) => pc.close());
      peerConnectionsRef.current.clear();
      
      // ⚠️ ANINDA KANALDAN ÇIK!
      if (connectedVoiceChannelIdRef.current) {
        console.log('🚪 Voice disconnected - Leaving channel IMMEDIATELY');
        
        // Mikrofonu kapat
        stopAudioMonitoring();
        
        // UI'ı güncelle
        setConnectedVoiceChannelId(null);
        connectedVoiceChannelIdRef.current = null;
        setVoiceUsers([]);
        
        // Çıkış sesi çal
        if (leaveSoundRef.current) {
          leaveSoundRef.current.currentTime = 0;
          leaveSoundRef.current.play().catch(e => console.log('Leave sound failed:', e));
        }
        
        showToast('error', 'Bağlantı kesildi! Sesli kanaldan çıktınız.');
      }
    });
    
    voiceSocket.on('connect_error', (error: any) => {
      console.error('❌ Voice connection error:', error);
    });
    
    voiceSocket.on('reconnect_attempt', (attemptNumber: number) => {
      console.log(`🔄 Attempting to reconnect to voice... (${attemptNumber})`);
      showToast('info', `Sesli kanala yeniden bağlanıyor... (${attemptNumber}/10)`);
    });
    
    voiceSocket.on('reconnect', (attemptNumber: number) => {
      console.log(`✅ Voice reconnected after ${attemptNumber} attempts`);
      showToast('success', 'Sesli kanala yeniden bağlandı!');
    });
    
    voiceSocket.on('reconnect_failed', () => {
      console.error('❌ Voice reconnection failed');
      showToast('error', 'Sesli kanala bağlanılamadı. Sayfayı yenileyin.');
      setConnectedVoiceChannelId(null);
      connectedVoiceChannelIdRef.current = null;
    });
    
    voiceSocket.on('voice-state-update', ({ channelId, users }: any) => {
      console.log('🎤 Voice state update - Channel:', channelId, 'Users:', users, 'CurrentChannel:', connectedVoiceChannelIdRef.current);
      if (channelId === connectedVoiceChannelIdRef.current && users) {
        console.log('✅ Updating voice users from state update');
        setVoiceUsers(users);
      }
    });
    
    voiceSocket.on('voice-users', ({ channelId, users }: any) => {
      console.log('👥 Voice users list - Channel:', channelId, 'Users:', users);
      if (users && users.length > 0) {
        console.log('✅ Setting voice users from list');
        setVoiceUsers(users);
      }
    });
    
    voiceSocket.on('channel-voice-users', ({ channelId, users }: any) => {
      console.log('📋 Channel voice users - Channel:', channelId, 'Users:', users);
      if (channelId === connectedVoiceChannelIdRef.current && users) {
        setVoiceUsers(users);
      }
    });
    
    voiceSocket.on('user-joined-voice', ({ channelId, userId, username, user: userData }: any) => {
      console.log('👋 User joined voice - Channel:', channelId, 'User:', username || userData?.username, 'CurrentChannel:', connectedVoiceChannelIdRef.current);
      
      // Sadece aktif kanalımızsa ekle
      if (channelId === connectedVoiceChannelIdRef.current) {
        // 🔊 BİRİ KATILDI SESİ ÇAL!
        if (joinSoundRef.current) {
          joinSoundRef.current.currentTime = 0;
          joinSoundRef.current.volume = 0.3; // Daha düşük (kendi sesimiz değil)
          joinSoundRef.current.play().catch(e => console.log('Join sound failed:', e));
        }
        
        setVoiceUsers(prev => {
          const actualUsername = username || userData?.username || 'Unknown';
          const actualUserId = userId || userData?.id;
          const exists = prev.some(u => u.userId === actualUserId);
          
          if (exists) {
            console.log('⚠️ User already in list:', actualUsername);
            return prev;
          }
          
          const newList = [...prev, { 
            userId: actualUserId, 
            username: actualUsername, 
            isMuted: false, 
            isSpeaking: false 
          }];
          console.log('✅ Added user to voice list. Total users:', newList.length);
          showToast('info', `${actualUsername} sesli kanala katıldı`);
          return newList;
        });
      }
    });
    
    voiceSocket.on('user-left-voice', ({ channelId, userId, username }: any) => {
      console.log('👋 User left voice:', userId, username);
      
      // 🔊 BİRİ ÇIKTI SESİ ÇAL!
      if (leaveSoundRef.current) {
        leaveSoundRef.current.currentTime = 0;
        leaveSoundRef.current.volume = 0.3; // Daha düşük
        leaveSoundRef.current.play().catch(e => console.log('Leave sound failed:', e));
      }
      
      setVoiceUsers(prev => {
        const leftUser = prev.find(u => u.userId === userId);
        if (leftUser) {
          showToast('info', `${leftUser.username || username || 'Kullanıcı'} sesli kanaldan ayrıldı`);
        }
        return prev.filter(u => u.userId !== userId);
      });
    });
    
    voiceSocket.on('user-speaking', ({ userId, isSpeaking }: any) => {
      setVoiceUsers(prev => prev.map(u => u.userId === userId ? { ...u, isSpeaking } : u));
    });
    
    voiceSocket.on('user-muted', ({ userId, isMuted }: any) => {
      setVoiceUsers(prev => prev.map(u => u.userId === userId ? { ...u, isMuted } : u));
    });
    
    // ✅ BACKEND'DEN GELEN ANA EVENT (TÜM KULLANICILAR)
    voiceSocket.on('voice-channel-update', ({ channelId, users }: any) => {
      console.log('🔊 Voice channel update - Channel:', channelId, 'Users:', users);
      
      if (users && Array.isArray(users)) {
        // TÜM KANALLAR için güncelle (önizleme için)
        setChannelVoiceUsers(prev => ({
          ...prev,
          [channelId]: users
        }));
        
        // Kendi kanalımız için de voiceUsers'ı güncelle
        if (channelId === connectedVoiceChannelIdRef.current) {
          const formattedUsers = users.map((u: any) => ({
            userId: u.id,
            username: u.username,
            isMuted: u.isMuted || false,
            isSpeaking: false
          }));
          
          // 🔊 KULLANICI SAYISI DEĞİŞTİ Mİ KONTROL ET!
          setVoiceUsers(prev => {
            // Yeni katılan var mı?
            formattedUsers.forEach(newUser => {
              const exists = prev.find(u => u.userId === newUser.userId);
              if (!exists && newUser.userId !== user?.id) {
                // 🔊 BİRİ KATILDI!
                console.log('🔊 Playing join sound for:', newUser.username);
                if (joinSoundRef.current) {
                  joinSoundRef.current.currentTime = 0;
                  joinSoundRef.current.volume = 0.3;
                  joinSoundRef.current.play().catch(e => console.log('Join sound failed:', e));
                }
                showToast('info', `${newUser.username} sesli kanala katıldı`);
              }
            });
            
            // Çıkan var mı?
            prev.forEach(oldUser => {
              const stillThere = formattedUsers.find(u => u.userId === oldUser.userId);
              if (!stillThere && oldUser.userId !== user?.id) {
                // 🔊 BİRİ ÇIKTI!
                console.log('🔊 Playing leave sound for:', oldUser.username);
                if (leaveSoundRef.current) {
                  leaveSoundRef.current.currentTime = 0;
                  leaveSoundRef.current.volume = 0.3;
                  leaveSoundRef.current.play().catch(e => console.log('Leave sound failed:', e));
                }
                showToast('info', `${oldUser.username} sesli kanaldan ayrıldı`);
              }
            });
            
            return formattedUsers;
          });
          
          console.log('✅ Setting voice users for current channel:', formattedUsers);
        }
      }
    });

    // WebRTC Events
    voiceSocket.on('peer-joined', async ({ peerId, username, shouldOffer, isScreenSharing, isVideoOn }: any) => {
      console.log('🔗 Peer joined:', peerId, username, 'Should offer:', shouldOffer, 'Screen:', isScreenSharing, 'Video:', isVideoOn);
      
      // ✅ DUPLICATE KONTROLÜ - Aynı peer zaten varsa skip et
      if (peerConnectionsRef.current.has(peerId)) {
        console.warn('⚠️ Peer already exists, skipping:', peerId);
        return;
      }
      
      // Yeni katılan varsa ve ekran/video paylaşıyorsa state'e ekle
      if (isScreenSharing || isVideoOn) {
        setRemoteUsers(prev => {
          const existing = prev.find(u => u.userId === peerId);
          if (existing) {
            return prev.map(u => u.userId === peerId ? { ...u, username, isScreenSharing, isVideoOn } : u);
          }
          return [...prev, { userId: peerId, username, isScreenSharing, isVideoOn }];
        });
        
        if (isScreenSharing) {
          showToast('info', `🖥️ ${username} ekran paylaşıyor`);
        }
      }
      
      const pc = new RTCPeerConnection({
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
          { urls: 'stun:stun2.l.google.com:19302' },
          { urls: 'stun:stun3.l.google.com:19302' },
          { urls: 'stun:stun4.l.google.com:19302' },
        ],
        iceCandidatePoolSize: 10
      });
      
      // Connection state monitoring
      pc.onconnectionstatechange = () => {
        console.log(`📡 Connection state for ${peerId}:`, pc.connectionState);
        if (pc.connectionState === 'connected') {
          console.log(`✅ Successfully connected to ${username}`);
        } else if (pc.connectionState === 'failed') {
          console.error(`❌ Connection failed to ${username}, attempting restart...`);
          // Bağlantı başarısız, peer'ı kapat ve tekrar bağlan
          setTimeout(() => {
            pc.close();
            peerConnectionsRef.current.delete(peerId);
            console.log(`🔄 Restarting connection to ${username}`);
          }, 1000);
        } else if (pc.connectionState === 'disconnected') {
          console.warn(`⚠️ Disconnected from ${username}, waiting for reconnection...`);
        }
      };
      
      pc.oniceconnectionstatechange = () => {
        console.log(`🧊 ICE state for ${peerId}:`, pc.iceConnectionState);
        
        // ICE bağlantısı başarısız olursa restart
        if (pc.iceConnectionState === 'failed') {
          console.error(`❌ ICE failed for ${username}, restarting ICE...`);
          pc.restartIce();
        } else if (pc.iceConnectionState === 'disconnected') {
          console.warn(`⚠️ ICE disconnected for ${username}, waiting...`);
          // 5 saniye sonra hala disconnected ise restart
          setTimeout(() => {
            if (pc.iceConnectionState === 'disconnected') {
              console.log(`🔄 ICE still disconnected, restarting for ${username}`);
              pc.restartIce();
            }
          }, 5000);
        }
      };
      
      // ICE candidate handler
      pc.onicecandidate = (event) => {
        if (event.candidate && voiceSocketRef.current) {
          console.log('🧊 Sending ICE candidate to:', peerId);
          voiceSocketRef.current.emit('signal', {
            type: 'ice-candidate',
            to: peerId,
            data: event.candidate
          });
        }
      };
      
      // Remote stream handler
      pc.ontrack = (event) => {
        console.log('🎧 Received remote track from:', username, 'Kind:', event.track.kind, 'ID:', event.track.id);
        const [remoteStream] = event.streams;
        
        if (remoteStream) {
          console.log('📦 Remote stream received, all tracks:', remoteStream.getTracks().map(t => t.kind));
          remoteStreamsRef.current.set(peerId, remoteStream);
          
          // Update remote users state with stream (for screen share & video)
          console.log('🔄 Updating remote users state for:', peerId, 'with stream');
          setRemoteUsers(prev => {
            const existing = prev.find(u => u.userId === peerId);
            if (existing) {
              console.log('✅ Updating existing user:', peerId, 'with stream');
              return prev.map(u => u.userId === peerId ? { ...u, stream: remoteStream } : u);
            }
            console.log('➕ Adding new user:', peerId, 'with stream');
            return [...prev, { userId: peerId, username, stream: remoteStream }];
          });
          
          // Remove existing audio element if any
          const existingAudio = document.getElementById(`audio-${peerId}`);
          if (existingAudio) existingAudio.remove();
          
          // Create audio element and play (only for audio tracks)
          if (event.track.kind === 'audio') {
            const audio = document.createElement('audio');
            audio.srcObject = remoteStream;
            audio.autoplay = true;
            audio.id = `audio-${peerId}`;
            audio.volume = userVolumeSettings[peerId] || 1.0;
            audio.style.display = 'none';
            document.body.appendChild(audio);
            
            audio.play().then(() => {
              console.log(`🔊 Audio playing for ${username}, volume: ${audio.volume}`);
            }).catch(err => {
              console.error(`❌ Audio play failed for ${username}:`, err);
              showToast('warning', `${username} için ses açmak için tıklayın`);
            });
          }
          
          // For video tracks (screen share or camera)
          if (event.track.kind === 'video') {
            console.log('📹 VIDEO TRACK RECEIVED from:', username);
            console.log('📹 Video track enabled:', event.track.enabled, 'readyState:', event.track.readyState);
            
            // Update theater presenter if this is the current presenter
            if (theaterPresenter?.userId === peerId || showTheaterMode) {
              console.log('🔄 Updating theater presenter stream for:', username);
              setTheaterPresenter(prev => prev ? { ...prev, stream: remoteStream } : null);
            }
          }
        }
      };
      
      // Add local stream
    if (localStreamRef.current) {
        console.log('📤 Adding local tracks to peer connection');
        localStreamRef.current.getTracks().forEach(track => {
          pc.addTrack(track, localStreamRef.current!);
          console.log('➕ Added track:', track.kind, 'enabled:', track.enabled);
        });
            } else {
        console.error('❌ No local stream available!');
      }
      
      peerConnectionsRef.current.set(peerId, pc);
      
      // Create offer if needed
      if (shouldOffer) {
        try {
          console.log('📤 Creating offer for:', username);
          const offer = await pc.createOffer({
            offerToReceiveAudio: true,
            offerToReceiveVideo: true // ✅ Video track'leri kabul et (screen share için)
          });
          await pc.setLocalDescription(offer);
          
          voiceSocketRef.current?.emit('signal', {
            type: 'offer',
            to: peerId,
            data: offer
          });
          console.log('✅ Offer sent to:', username);
        } catch (error) {
          console.error('❌ Offer creation failed:', error);
        }
      }
    });
    
    voiceSocket.on('peer-left', ({ peerId }: any) => {
      console.log('👋 Peer left:', peerId);
      
      // Clean up peer connection
      const pc = peerConnectionsRef.current.get(peerId);
      if (pc) {
        pc.close();
        peerConnectionsRef.current.delete(peerId);
      }
      
      // Remove audio element
      const audio = document.getElementById(`audio-${peerId}`);
      if (audio) {
        audio.remove();
      }
      
      remoteStreamsRef.current.delete(peerId);
      
      // Remove from remote users
      setRemoteUsers(prev => prev.filter(u => u.userId !== peerId));
    });
    
    // Screen share events (Broadcast to all in channel)
    voiceSocket.on('screen-share-started', ({ userId, username }: { userId: string; username: string }) => {
      if (userId === user?.id) return; // Ignore self
      
      console.log('📺 Screen share started by:', username);
      setRemoteUsers(prev => {
        const existing = prev.find(u => u.userId === userId);
        if (existing) {
          return prev.map(u => u.userId === userId ? { ...u, isScreenSharing: true } : u);
        }
        return [...prev, { userId, username, isScreenSharing: true }];
      });
      showToast('info', `🖥️ ${username} ekran paylaşıyor`);
    });

    voiceSocket.on('screen-share-stopped', ({ userId }: { userId: string }) => {
      console.log('📺 Screen share stopped by:', userId);
      setRemoteUsers(prev => prev.map(u => 
        u.userId === userId ? { ...u, isScreenSharing: false, stream: undefined } : u
      ));
      
      // HERKES İÇİN KAPAT - Kim olursa olsun
      if (theaterPresenter?.userId === userId || showTheaterMode) {
        setShowTheaterMode(false);
        setTheaterPresenter(null);
        showToast('info', 'Ekran paylaşımı sona erdi');
      }
    });

    voiceSocket.on('video-started', ({ userId, username }: { userId: string; username: string }) => {
      if (userId === user?.id) return; // Ignore self
      
      console.log('📹 Video started by:', username);
      setRemoteUsers(prev => {
        const existing = prev.find(u => u.userId === userId);
        if (existing) {
          return prev.map(u => u.userId === userId ? { ...u, isVideoOn: true } : u);
        }
        return [...prev, { userId, username, isVideoOn: true }];
      });
    });

    voiceSocket.on('video-stopped', ({ userId }: { userId: string }) => {
      console.log('📹 Video stopped by:', userId);
      setRemoteUsers(prev => prev.map(u => 
        u.userId === userId ? { ...u, isVideoOn: false } : u
      ));
    });
    
    voiceSocket.on('signal', async ({ from, type, data }: any) => {
      console.log('📨 Signal from:', from, 'Type:', type);
      
      let pc = peerConnectionsRef.current.get(from);
      
      if (!pc && type === 'offer') {
        console.log('🆕 Creating new peer connection for incoming offer from:', from);
        // Create new peer connection for incoming offer
        pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
            { urls: 'stun:stun2.l.google.com:19302' },
            { urls: 'stun:stun3.l.google.com:19302' },
            { urls: 'stun:stun4.l.google.com:19302' },
          ],
          iceCandidatePoolSize: 10
        });
        
        pc.onconnectionstatechange = () => {
          console.log(`📡 Connection state for ${from}:`, pc!.connectionState);
          if (pc!.connectionState === 'connected') {
            console.log(`✅ Successfully connected to peer ${from}`);
          } else if (pc!.connectionState === 'failed') {
            console.error(`❌ Connection failed to ${from}, attempting restart...`);
            setTimeout(() => {
              pc!.close();
              peerConnectionsRef.current.delete(from);
              console.log(`🔄 Restarting connection to ${from}`);
            }, 1000);
          }
        };
        
        pc.oniceconnectionstatechange = () => {
          console.log(`🧊 ICE state for ${from}:`, pc!.iceConnectionState);
          
          if (pc!.iceConnectionState === 'failed') {
            console.error(`❌ ICE failed for ${from}, restarting ICE...`);
            pc!.restartIce();
          } else if (pc!.iceConnectionState === 'disconnected') {
            console.warn(`⚠️ ICE disconnected for ${from}, waiting...`);
            setTimeout(() => {
              if (pc!.iceConnectionState === 'disconnected') {
                console.log(`🔄 ICE still disconnected, restarting for ${from}`);
                pc!.restartIce();
              }
            }, 5000);
          }
        };
        
    pc.onicecandidate = (event) => {
      if (event.candidate && voiceSocketRef.current) {
            console.log('🧊 Sending ICE candidate to:', from);
            voiceSocketRef.current.emit('signal', {
              type: 'ice-candidate',
              to: from,
              data: event.candidate
        });
      }
    };

    pc.ontrack = (event) => {
          console.log('🎧 Received remote stream from signal:', from, 'Track:', event.track.kind);
      const [remoteStream] = event.streams;
          
          if (remoteStream) {
            remoteStreamsRef.current.set(from, remoteStream);
            
            const existingAudio = document.getElementById(`audio-${from}`);
            if (existingAudio) existingAudio.remove();
            
            const audio = document.createElement('audio');
            audio.srcObject = remoteStream;
        audio.autoplay = true;
            audio.id = `audio-${from}`;
            audio.volume = userVolumeSettings[from] || 1.0; // ← SES SEVİYESİ AYARI!
        audio.style.display = 'none';
        document.body.appendChild(audio);
            
            audio.play().then(() => {
              console.log(`🔊 Audio playing for peer: ${from}, volume: ${audio.volume}`);
            }).catch(err => {
              console.error(`❌ Audio play failed for peer ${from}:`, err);
            });
          }
        };
        
        if (localStreamRef.current) {
          console.log('📤 Adding local tracks to new peer connection');
          localStreamRef.current.getTracks().forEach(track => {
            pc!.addTrack(track, localStreamRef.current!);
            console.log('➕ Added track:', track.kind);
          });
        }
        
        peerConnectionsRef.current.set(from, pc);
      }
      
      if (pc) {
        try {
          if (type === 'offer') {
            console.log('📥 Processing offer from:', from);
            await pc.setRemoteDescription(new RTCSessionDescription(data));
            const answer = await pc.createAnswer({
              offerToReceiveAudio: true,
              offerToReceiveVideo: true // ✅ Video track'leri kabul et
            });
            await pc.setLocalDescription(answer);
            
            voiceSocketRef.current?.emit('signal', {
              type: 'answer',
              to: from,
              data: answer
            });
            console.log('✅ Answer sent to:', from);
          } else if (type === 'answer') {
            console.log('📥 Processing answer from:', from);
            await pc.setRemoteDescription(new RTCSessionDescription(data));
            console.log('✅ Answer processed for:', from);
          } else if (type === 'ice-candidate') {
            console.log('🧊 Adding ICE candidate from:', from);
            await pc.addIceCandidate(new RTCIceCandidate(data));
          }
        } catch (error) {
          console.error(`❌ Signal processing error for ${from}:`, error);
        }
      } else {
        console.warn(`⚠️ No peer connection found for ${from}`);
      }
    });
    
    return () => { voiceSocket.disconnect(); };
  }, [accessToken]);

  useEffect(() => {
    if (!socketRef.current || !selectedChannel || selectedChannel.type !== 'TEXT') return;
    if (currentChannelIdRef.current && currentChannelIdRef.current !== selectedChannel.id) {
      socketRef.current.emit('leave-channel', { channelId: currentChannelIdRef.current });
    }
    currentChannelIdRef.current = selectedChannel.id;
    socketRef.current.emit('join-channel', { channelId: selectedChannel.id });
    loadMessages(selectedChannel.id);
  }, [selectedChannel]);

  const loadServers = async () => { try { const response = await serversApi.getAll(); setServers(response.data); if (response.data.length > 0) setSelectedServer(response.data[0]); } catch (error) { console.error('Error:', error); } };
  const loadChannels = async (serverId: string) => { try { const response = await channelsApi.getByServer(serverId); setChannels(response.data); if (response.data.length > 0) setSelectedChannel(response.data[0]); } catch (error) { console.error('Error:', error); } };
  const loadServerMembers = async (serverId: string) => { 
    try { 
      const response = await serversApi.getMembers(serverId); 
      const members = response.data.map((m: any) => ({ 
        userId: m.userId || m.user?.id, 
        username: m.user?.username || 'Unknown', 
        displayName: m.user?.displayName, 
        isOnline: m.user?.isOnline || false 
      }));
      setServerMembers(members);
      
      // Presence is updated automatically via broadcasts - NO manual checks!
    } catch (error) { 
      console.error('Error:', error); 
    } 
  };
  
  // Screen Share Handlers
  const handleStartScreenShare = async (stream: MediaStream) => {
    try {
      screenStreamRef.current = stream;
      setIsScreenSharing(true);
      showToast('success', '🖥️ Ekran paylaşımı başladı');
      
      console.log('🖥️ Screen share stream acquired, tracks:', stream.getTracks().map(t => t.kind));
      
      // RTC üzerinden ekran paylaşımını broadcast et
      if (connectedVoiceChannelId && voiceSocketRef.current) {
        const screenTrack = stream.getVideoTracks()[0];
        
        if (!screenTrack) {
          console.error('❌ No video track in screen share stream!');
          showToast('error', 'Ekran paylaşımı video track bulunamadı');
          return;
        }
        
        console.log('📤 Broadcasting screen share to', peerConnectionsRef.current.size, 'peers');
        
        // Her peer connection'a screen video track ekle
        peerConnectionsRef.current.forEach(async (pc, peerId) => {
          try {
            console.log('➕ Adding screen track to peer:', peerId);
            
            // Mevcut sender'ları kontrol et
            const senders = pc.getSenders();
            console.log('📤 Current senders:', senders.map(s => s.track?.kind));
            
            pc.addTrack(screenTrack, stream);
            console.log('✅ Screen track added');
            
            // Yeni offer oluştur (renegotiation için)
            const offer = await pc.createOffer({
              offerToReceiveAudio: true,
              offerToReceiveVideo: true  // ✅ Video kabul et!
            });
            await pc.setLocalDescription(offer);
            
            voiceSocketRef.current?.emit('signal', {
              type: 'offer',
              to: peerId,
              data: offer
            });
            console.log('✅ Screen share renegotiation offer sent to:', peerId);
          } catch (error) {
            console.error('❌ Failed to add screen track to peer:', peerId, error);
          }
        });
        
        // Notify others that screen share started
        voiceSocketRef.current.emit('screen-share-started', {
          channelId: connectedVoiceChannelId,
          userId: user?.id,
          username: user?.username,
        });
        
        // Set presenter for theater mode (with stream!)
        console.log('🎭 Setting theater presenter:', user!.username, 'Stream:', stream, 'Tracks:', stream.getTracks().length);
        setTheaterPresenter({
          userId: user!.id,
          username: user!.username,
          stream,
        });
        setShowTheaterMode(true);
      }
    } catch (error: any) {
      console.error('❌ Screen share error:', error);
      showToast('error', 'Ekran paylaşımı başlatılamadı');
    }
  };

  const handleStopScreenShare = () => {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(track => track.stop());
      screenStreamRef.current = null;
    }
    setIsScreenSharing(false);
    setShowTheaterMode(false);
    setTheaterPresenter(null);
    showToast('info', '🖥️ Ekran paylaşımı durduruldu');
    
    // Notify others
    if (connectedVoiceChannelId && voiceSocketRef.current) {
      voiceSocketRef.current.emit('screen-share-stopped', {
        channelId: connectedVoiceChannelId,
        userId: user?.id,
      });
    }
  };

  // Video Handlers
  const handleStartVideo = async (stream: MediaStream) => {
    try {
      videoStreamRef.current = stream;
      setIsVideoOn(true);
      showToast('success', '📹 Kamera açıldı');
      
      // RTC üzerinden video'yu broadcast et
      if (connectedVoiceChannelId && voiceSocketRef.current) {
        peerConnectionsRef.current.forEach((pc, peerId) => {
          const videoTrack = stream.getVideoTracks()[0];
          const sender = pc.getSenders().find(s => s.track?.kind === 'video');
          
          if (sender) {
            sender.replaceTrack(videoTrack);
          } else {
            pc.addTrack(videoTrack, stream);
          }
        });
        
        voiceSocketRef.current.emit('video-started', {
          channelId: connectedVoiceChannelId,
          userId: user?.id,
        });
      }
    } catch (error: any) {
      showToast('error', 'Kamera açılamadı');
    }
  };

  const handleStopVideo = () => {
    if (videoStreamRef.current) {
      videoStreamRef.current.getTracks().forEach(track => track.stop());
      videoStreamRef.current = null;
    }
    setIsVideoOn(false);
    showToast('info', '📹 Kamera kapatıldı');
    
    // Notify others
    if (connectedVoiceChannelId && voiceSocketRef.current) {
      voiceSocketRef.current.emit('video-stopped', {
        channelId: connectedVoiceChannelId,
        userId: user?.id,
      });
    }
  };

  const loadMessages = async (channelId: string) => {
    try {
      setLoading(true);
      const response = await messagesApi.getChannelMessages(channelId, 50);
      const data = response.data;
      const messageList = Array.isArray(data) ? data : (data.messages || []);
      setMessages(messageList.sort((a: Message, b: Message) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()));
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    } catch (error) {
      setMessages([]);
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!newMessage.trim() && !selectedFile) || !selectedChannel || !selectedChannel.id) return;
    
    const messageContent = newMessage;
    const fileToUpload = selectedFile;
    setNewMessage(''); // Hemen temizle
    setSelectedFile(null); // Dosyayı temizle
    
    try {
      let fileData = null;
      
      // Dosya varsa önce upload et (GERÇEK UPLOAD!)
      if (fileToUpload) {
        setIsUploading(true);
        setUploadProgress(0);
        
        const uploadResponse = await uploadApi.uploadFile(fileToUpload, (progress) => {
          setUploadProgress(progress);
        });
        
        fileData = uploadResponse.data;
        setIsUploading(false);
        setUploadProgress(100);
      }
      
      // Mesajı gönder
      const finalContent = messageContent || (fileData ? `📎 ${fileData.filename}` : '');
      const response = await messagesApi.sendMessage(selectedChannel.id, finalContent);
      
      // Optimistically add message
      if (response.data && user) {
        const newMsg = {
          id: response.data.id || Math.random().toString(),
          content: finalContent,
          channelId: selectedChannel.id,
          createdAt: new Date().toISOString(),
          user: {
            id: user.id,
            username: user.username,
            displayName: user.displayName
          }
        };
        setMessages(prev => [...prev, newMsg]);
        
        if (fileData) {
          showToast('success', `✅ Dosya yüklendi: ${fileData.filename}`);
        }
      }
    } catch (error: any) {
      showToast('error', error.response?.data?.message || 'Mesaj gönderilemedi');
      setNewMessage(messageContent);
      setSelectedFile(fileToUpload);
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const createChannel = async () => {
    if (!newChannelName.trim() || !selectedServer) return;
    try {
      await channelsApi.create(selectedServer.id, { name: newChannelName, type: newChannelType });
      setNewChannelName('');
      setShowNewChannelModal(false);
      loadChannels(selectedServer.id);
      showToast('success', 'Kanal oluşturuldu!');
    } catch (error: any) {
      showToast('error', error.response?.data?.message || 'Kanal oluşturulamadı');
    }
  };

  const createServer = async () => {
    if (!newServerName.trim()) return;
    try {
      await serversApi.create({ name: newServerName, description: newServerDescription });
      setNewServerName('');
      setNewServerDescription('');
      setShowNewServerModal(false);
      loadServers();
      showToast('success', 'Sunucu oluşturuldu!');
    } catch (error: any) {
      showToast('error', error.response?.data?.message || 'Sunucu oluşturulamadı');
    }
  };

  const generateInvite = async () => {
    if (!selectedServer) return;
    try {
      const response = await serversApi.createInvite(selectedServer.id);
      const code = response.data.inviteCode || response.data.code;
      setInviteCode(code);
      setShowInviteModal(true);
      showToast('success', 'Davet linki oluşturuldu!');
    } catch (error: any) {
      showToast('error', error.response?.data?.message || 'Davet linki oluşturulamadı');
    }
  };

  // Ses seviyesi izlemeyi başlat
  const startAudioMonitoring = async (): Promise<boolean> => {
    try {
      console.log('🎙️ Requesting microphone access...');
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        }, 
        video: false 
      });
      
      stream.getTracks().forEach(track => track.enabled = true);
      localStreamRef.current = stream;
      console.log('✅ Microphone stream acquired');
      
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioAnalyserRef.current = audioContextRef.current.createAnalyser();
      
      // ⚡ DENGELI DISCORD AYARLARI (Optimal Balance)
      audioAnalyserRef.current.fftSize = 256; // Optimal hız/kalite dengesi
      audioAnalyserRef.current.minDecibels = -90; // Standart aralık
      audioAnalyserRef.current.maxDecibels = -20; // Gürültü toleransı
      audioAnalyserRef.current.smoothingTimeConstant = 0.4; // Dengeli (çok hızlı değil, çok yavaş değil)
      
      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(audioAnalyserRef.current);
      
      const dataArray = new Uint8Array(audioAnalyserRef.current.frequencyBinCount);
      let lastSpeakingState = false;
      
      audioLevelIntervalRef.current = window.setInterval(() => {
        if (!audioAnalyserRef.current || isMuted) {
          setMyAudioLevel(0);
          return;
        }
        
        // Frekans verilerini al
        audioAnalyserRef.current.getByteFrequencyData(dataArray);
        
        // Ortalama hesapla
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const average = sum / dataArray.length;
        const level = average / 255;
        
        setMyAudioLevel(level);
        
        // ⚡ DISCORD STANDART THRESHOLD (0.015 - Optimal!)
        const isSpeaking = level > 0.015;
        if (isSpeaking !== lastSpeakingState && voiceSocketRef.current) {
          console.log(`🎤 Speaking: ${isSpeaking}, level: ${level.toFixed(3)}`);
          voiceSocketRef.current.emit('speaking', { isSpeaking });
          
          // ⏰ AFK TIMER'I SIFIRLA! (Konuşma = Aktif)
          if (isSpeaking) {
            lastActivityRef.current = Date.now();
          }
          
          // Kendi kullanıcının isSpeaking state'ini güncelle
          if (user) {
            setVoiceUsers(prev => prev.map(u => 
              u.userId === user.id ? { ...u, isSpeaking } : u
            ));
          }
          
          lastSpeakingState = isSpeaking;
        }
      }, 80); // ⚡ DENGELI GÜNCELLEME (80ms - Optimal!)
      
      console.log('✅ Audio monitoring started');
      return true;
    } catch (error) {
      console.error('❌ Mikrofon erişim hatası:', error);
      showToast('error', 'Mikrofon erişimi reddedildi');
      return false;
    }
  };

  const stopAudioMonitoring = () => {
    if (audioLevelIntervalRef.current) {
      clearInterval(audioLevelIntervalRef.current);
      audioLevelIntervalRef.current = null;
    }
    
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => {
        track.stop();
        track.enabled = false;
      });
      localStreamRef.current = null;
    }
    
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(e => console.warn('AudioContext close failed:', e));
      audioContextRef.current = null;
    }
    
    // Close all peer connections
    peerConnectionsRef.current.forEach((pc, peerId) => {
      try {
        pc.close();
      } catch (e) {
        console.warn(`Failed to close peer ${peerId}:`, e);
      }
      
      // Remove audio element
      const audio = document.getElementById(`audio-${peerId}`);
      if (audio) {
        audio.pause();
        audio.srcObject = null;
        audio.remove();
      }
    });
    peerConnectionsRef.current.clear();
    remoteStreamsRef.current.clear();
    
    audioAnalyserRef.current = null;
    setMyAudioLevel(0);
    
    // Force garbage collection hint
    console.log('🧹 Audio monitoring stopped and resources cleaned');
  };

  const showToast = (type: 'success' | 'error' | 'info' | 'warning', message: string) => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { id, type, message }]);
  };

  const removeToast = (id: string) => setToasts(prev => prev.filter(t => t.id !== id));
  const textChannels = channels.filter(ch => ch.type === 'TEXT');
  const voiceChannels = channels.filter(ch => ch.type === 'VOICE');

  return (
    <div className="h-screen flex flex-col bg-white">
      {/* Modals */}
      {showInviteModal && inviteCode && selectedServer && (
        <ServerInviteModal inviteCode={inviteCode} serverName={selectedServer.name} onClose={() => setShowInviteModal(false)} showToast={showToast} />
      )}
      <CreateChannelModal isOpen={showNewChannelModal} channelName={newChannelName} channelType={newChannelType} onNameChange={setNewChannelName} onTypeChange={setNewChannelType} onCreate={createChannel} onClose={() => setShowNewChannelModal(false)} />
      <CreateServerModal isOpen={showNewServerModal} serverName={newServerName} serverDescription={newServerDescription} onNameChange={setNewServerName} onDescriptionChange={setNewServerDescription} onCreate={createServer} onClose={() => setShowNewServerModal(false)} />
      <SettingsModal isOpen={showSettingsModal} onClose={() => setShowSettingsModal(false)} showToast={showToast} />

      {view === 'friends' ? (
        <FriendsView onClose={() => setView('servers')} showToast={showToast} />
      ) : view === 'dm' ? (
        <DirectMessagesView showToast={showToast} />
      ) : (
        <>
          {/* Mobile Header */}
          <div className="lg:hidden bg-white border-b border-neutral-200 px-4 py-3 flex items-center justify-between shadow-sm">
            <button onClick={() => setShowMobileMenu(!showMobileMenu)} className="p-2 hover:bg-neutral-100 rounded-xl">
              <Menu className="w-5 h-5" />
              </button>
            <h1 className="font-bold text-lg text-blue-600">AsforceS</h1>
            <div className="flex gap-2">
              <button onClick={() => setView('friends')} className="p-2 hover:bg-neutral-100 rounded-xl"><Users className="w-5 h-5" /></button>
              <button onClick={() => setView('dm')} className="p-2 hover:bg-neutral-100 rounded-xl"><MessageSquare className="w-5 h-5" /></button>
            </div>
              </div>
              
          {/* Horizontal Server Bar - Desktop Only */}
          <div className="hidden lg:flex bg-gradient-to-r from-blue-600 via-blue-700 to-blue-600 border-b-2 border-blue-800 shadow-xl w-full">
            <div className="flex items-center gap-3 px-4 py-3 overflow-x-auto flex-1">
              {/* Logo */}
              <div className="flex items-center gap-3 pr-4 border-r border-white/20">
                <div className="relative group">
                  <div className="absolute inset-0 bg-white/30 rounded-xl blur-md group-hover:blur-lg transition-all"></div>
                  <div className="relative w-11 h-11 rounded-xl bg-white flex items-center justify-center shadow-xl">
                    <span className="font-black text-xl bg-gradient-to-br from-blue-600 to-blue-700 bg-clip-text text-transparent">A</span>
              </div>
              </div>
            </div>
              
              {/* Server List */}
              <div className="flex gap-2 flex-1">
            {servers.map((server) => (
            <button
              key={server.id}
              onClick={() => setSelectedServer(server)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-200 group hover:scale-105 ${
                selectedServer?.id === server.id
                        ? 'bg-white text-blue-600 shadow-lg'
                        : 'bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm'
                    }`}
                    title={server.name}
                  >
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold shadow-md ${
                      selectedServer?.id === server.id 
                        ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white' 
                        : 'bg-white/20 text-white'
                    }`}>
                      {server.icon || server.name.charAt(0).toUpperCase()}
                </div>
                    <span className="font-semibold text-sm whitespace-nowrap max-w-[120px] truncate">{server.name}</span>
            </button>
          ))}
          
                {/* Add Server */}
          <button
            onClick={() => setShowNewServerModal(true)}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm transition-all duration-200 hover:scale-105 border-2 border-dashed border-white/30"
          >
                  <div className="w-9 h-9 rounded-lg bg-white/20 flex items-center justify-center">
                    <Plus className="w-5 h-5" />
                  </div>
                  <span className="font-semibold text-sm whitespace-nowrap">Sunucu Ekle</span>
          </button>
        </div>
              
              {/* Right Side - User & Logout */}
              <div className="flex items-center gap-3 pl-4 border-l border-white/20">
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-xl">
                  <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center text-white font-bold text-sm">
                    {user?.username?.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-white font-semibold text-sm">{user?.username}</span>
                </div>
            <button
                  onClick={logout} 
                  className="p-2 bg-red-500/20 hover:bg-red-500 text-red-200 hover:text-white rounded-lg transition-all duration-200 hover:scale-110"
            title="Çıkış Yap"
          >
            <LogOut className="w-5 h-5" />
          </button>
              </div>
        </div>
      </div>

          {/* Main Content Wrapper */}
      <div className="flex-1 flex overflow-hidden">
            {/* Channel Sidebar - Clean White Design */}
            <div className={`${showMobileMenu ? 'flex' : 'hidden lg:flex'} w-72 bg-white flex-col border-r border-neutral-200 shadow-lg fixed lg:static inset-y-0 left-0 z-40 lg:z-auto`}>
            <div className="px-6 py-5 bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-md relative">
              <button 
                onClick={() => setShowMobileMenu(false)}
                className="lg:hidden absolute top-4 right-4 p-2 hover:bg-white/20 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
              <h2 className="font-bold text-xl truncate mb-1 pr-12 lg:pr-0">{selectedServer?.name || 'Sunucu Seç'}</h2>
              <p className="text-xs text-blue-100">{serverMembers.length} üye çevrimiçi</p>
          </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {/* Text Channels */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Metin Kanalları</h3>
                  <button onClick={() => setShowNewChannelModal(true)} className="p-1.5 hover:bg-blue-100 rounded-lg text-blue-600 transition-colors">
                    <Plus className="w-4 h-4" />
                </button>
              </div>
                <div className="space-y-1.5">
                {textChannels.map((channel) => (
                  <button
                    key={channel.id}
                      onClick={() => {
                        setSelectedChannel(channel);
                        setShowDMPanel(false); // DM'i kapat
                        setShowFriendsPanel(false); // Arkadaşlar panelini kapat
                      }}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                      selectedChannel?.id === channel.id
                          ? 'bg-blue-500 text-white shadow-lg scale-105'
                          : 'text-neutral-700 hover:bg-blue-50 hover:scale-102'
                    }`}
                  >
                      <Hash className="w-5 h-5" />
                      <span className="font-medium truncate">{channel.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Voice Channels */}
              {voiceChannels.length > 0 && (
            <div>
                  <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3">Sesli Kanallar</h3>
                  <div className="space-y-2">
                {voiceChannels.map((channel) => {
                  const isConnected = connectedVoiceChannelId === channel.id;
                      // Bağlı kanalsa voiceUsers (mikrofon animasyonu için), değilse channelVoiceUsers (önizleme için)
                      const currentChannelUsers = isConnected 
                        ? voiceUsers.map(u => ({ id: u.userId, username: u.username, isMuted: u.isMuted, isSpeaking: u.isSpeaking }))
                        : (channelVoiceUsers[channel.id] || []);
                  
                  return (
                    <div key={channel.id}>
                      <button
                            onClick={() => {
                              if (isConnected) {
                                  // Ayrıl
                                  stopAudioMonitoring();
                                  voiceSocketRef.current?.emit('leave-voice');
                                  setConnectedVoiceChannelId(null);
                                  connectedVoiceChannelIdRef.current = null;
                                  setVoiceUsers([]);
                                  
                                  // 💾 LocalStorage'dan sil
                                  localStorage.removeItem('lastVoiceChannel');
                                  
                                  // 🔊 ÇIKIŞ SESİ ÇAL!
                                  if (leaveSoundRef.current) {
                                    leaveSoundRef.current.currentTime = 0;
                                    leaveSoundRef.current.play().catch(e => console.log('Sound play failed:', e));
                                  }
                                  
                                  console.log('🚪 Left voice channel:', channel.id);
                              } else {
                                // Katıl
                                (async () => {
                                  setConnectedVoiceChannelId(channel.id);
                                  connectedVoiceChannelIdRef.current = channel.id;
                                  
                                  // Mikrofonu başlat ve BEKLE
                                  const success = await startAudioMonitoring();
                                  
                                  if (!success) {
                                    console.error('❌ Mikrofon başlatılamadı, sesli kanala katılma iptal edildi');
                                    setConnectedVoiceChannelId(null);
                                    connectedVoiceChannelIdRef.current = null;
                                    return;
                                  }
                                  
                                  // ✅ Mikrofon hazır, şimdi sesli kanala katıl
                                  if (voiceSocketRef.current && user && selectedServer) {
                                    voiceSocketRef.current.emit('join-voice', { 
                                      roomId: selectedServer.id,
                                      channelId: channel.id,
                                      userId: user.id,
                                      username: user.username
                                    });
                                    console.log('🎤 Joining voice - Server:', selectedServer.id, 'Channel:', channel.id);
                                    
                                    // ✅ KENDİNİ HEMEN EKLE!
                                    setVoiceUsers([{
                                      userId: user.id,
                                      username: user.username,
                                      isMuted: false,
                                      isSpeaking: false
                                    }]);
                                    console.log('👤 Added self to voice immediately:', user.username);
                                    
                                    // 💾 Kanala katılınca localStorage'a kaydet
                                    localStorage.setItem('lastVoiceChannel', JSON.stringify({
                                      channelId: channel.id,
                                      serverId: selectedServer.id,
                                      timestamp: Date.now()
                                    }));
                                    
                                    // 🔊 GİRİŞ SESİ ÇAL!
                                    setTimeout(() => {
                                      if (joinSoundRef.current) {
                                        joinSoundRef.current.currentTime = 0;
                                        joinSoundRef.current.volume = 0.5; // Orta seviye
                                        joinSoundRef.current.play().catch(e => console.log('Sound play failed:', e));
                                      }
                                    }, 500); // Mikrofon başladıktan sonra
                                  }
                                })();
                              }
                            }}
                            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 ${
                          isConnected
                                ? 'bg-green-500 text-white shadow-lg'
                                : 'text-neutral-700 hover:bg-neutral-100'
                            }`}
                          >
                            <div className="flex items-center space-x-3">
                              <Volume2 className="w-5 h-5" />
                              <span className="font-medium">{channel.name}</span>
                            </div>
                            {currentChannelUsers.length > 0 && (
                              <span className="text-xs px-2 py-1 bg-white/20 rounded-full font-semibold">{currentChannelUsers.length}</span>
                        )}
                      </button>
                      
                          {/* Sesli kanaldaki kullanıcılar - Her zaman göster */}
                          {currentChannelUsers.length > 0 && (
                            <div className="ml-4 mt-3 space-y-2">
                              {currentChannelUsers.map((vu) => {
                                const isMe = vu.id === user?.id;
                                const currentIsSpeaking = isMe ? (myAudioLevel > 0.015 && !isMuted) : vu.isSpeaking;
                            
                            return (
                              <div 
                                    key={vu.id} 
                                    className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-300 ${
                                      currentIsSpeaking 
                                        ? 'bg-gradient-to-r from-green-50 to-emerald-50 shadow-md border-l-4 border-green-500 scale-105' 
                                        : 'bg-white/60 hover:bg-white hover:shadow-sm border-l-4 border-transparent'
                                    }`}
                                  >
                                    <div className="relative">
                                      <div className={`w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-lg transition-all duration-300 ${
                                        currentIsSpeaking ? 'ring-4 ring-green-400 ring-offset-2 scale-110' : 'ring-2 ring-white'
                                      }`}>
                                        {vu.username?.charAt(0).toUpperCase() || 'U'}
                                      </div>
                                      {currentIsSpeaking && (
                                        <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white animate-ping"></div>
                                  )}
                                </div>
                                    
                                <div className="flex-1 min-w-0">
                                      <div className={`font-semibold text-sm truncate ${currentIsSpeaking ? 'text-green-700' : 'text-neutral-800'}`}>
                                        {vu.username} {isMe && <span className="text-xs text-blue-600">(Sen)</span>}
                                </div>
                                      {currentIsSpeaking && (
                                        <div className="flex items-center gap-1 mt-0.5">
                                          <div className="flex gap-0.5">
                                            <div className="w-1 h-3 bg-green-500 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></div>
                                            <div className="w-1 h-4 bg-green-500 rounded-full animate-bounce" style={{animationDelay: '100ms'}}></div>
                                            <div className="w-1 h-3 bg-green-500 rounded-full animate-bounce" style={{animationDelay: '200ms'}}></div>
                                            <div className="w-1 h-2 bg-green-500 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></div>
                                          </div>
                                          <span className="text-xs text-green-600 font-medium ml-1">Konuşuyor...</span>
                                  </div>
                                )}
                                      {!isMe && (
                                        <div className="mt-2">
                                          <div className="flex items-center gap-2">
                                            <Volume2 className="w-3 h-3 text-neutral-500" />
                                            <input
                                              type="range"
                                              min="0"
                                              max="100"
                                              value={(userVolumeSettings[vu.id] || 1) * 100}
                                              onChange={(e) => {
                                                const volume = parseInt(e.target.value) / 100;
                                                setUserVolumeSettings(prev => ({ ...prev, [vu.id]: volume }));
                                                const audioEl = document.getElementById(`audio-${vu.id}`) as HTMLAudioElement;
                                                if (audioEl) {
                                                  audioEl.volume = volume;
                                                  console.log(`🔊 Volume for ${vu.username}: ${volume}`);
                                                }
                                              }}
                                              className="flex-1 h-1.5 bg-neutral-200 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-blue-600"
                                            />
                                            <span className="text-xs text-neutral-600 font-medium w-8">{Math.round((userVolumeSettings[vu.id] || 1) * 100)}%</span>
                              </div>
                        </div>
                      )}
                    </div>
                                    
                                    {vu.isMuted ? (
                                      <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center shadow-md">
                                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
                                        </svg>
              </div>
                                    ) : currentIsSpeaking ? (
                                      <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-green-500 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                                        <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                                          <path d="M10 3a1 1 0 011 1v12a1 1 0 11-2 0V4a1 1 0 011-1z"/>
                                          <path d="M6 7a1 1 0 011 1v4a1 1 0 11-2 0V8a1 1 0 011-1zM14 7a1 1 0 011 1v4a1 1 0 11-2 0V8a1 1 0 011-1z"/>
                                          <path d="M4 10a1 1 0 011 1v2a1 1 0 11-2 0v-2a1 1 0 011-1zM16 10a1 1 0 011 1v2a1 1 0 11-2 0v-2a1 1 0 011-1z"/>
                                        </svg>
            </div>
                                    ) : (
                                      <div className="w-8 h-8 bg-neutral-200 rounded-full flex items-center justify-center">
                                        <svg className="w-4 h-4 text-neutral-500" fill="currentColor" viewBox="0 0 20 20">
                                          <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" />
                                        </svg>
          </div>
                                    )}
            </div>
                                );
                              })}
              </div>
                )}
              </div>
                      );
                    })}
            </div>
                </div>
              )}

              {/* Quick Access - Portal, Friends, Settings */}
              <div className="pt-4 border-t-2 border-neutral-200">
                <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                  ⚡ Hızlı Erişim
                </h3>
                <div className="space-y-1.5">
                  <a
                    href="/"
                    target="_blank"
                    className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl bg-gradient-to-r from-blue-50 to-blue-100 text-blue-700 hover:from-blue-100 hover:to-blue-200 transition-all duration-200 shadow-sm hover:shadow-md"
                  >
                    <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center text-white shadow-sm">🏠</div>
                    <div className="flex-1">
                      <div className="font-bold">Portal</div>
                      <div className="text-xs text-blue-600">Ana sayfa</div>
                    </div>
                  </a>
                  <button
                    onClick={() => { 
                      setShowFriendsPanel(true); 
                      setShowDMPanel(false); 
                      setSelectedChannel(null); // Kanal seçimini kaldır
                    }}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                      showFriendsPanel ? 'bg-blue-500 text-white' : 'text-neutral-700 hover:bg-blue-50 hover:text-blue-600'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                      showFriendsPanel ? 'bg-white/20 text-white' : 'bg-neutral-100 group-hover:bg-blue-500 group-hover:text-white'
                    }`}>
                      <Users className="w-5 h-5" />
                    </div>
                    <span className="font-semibold">Arkadaşlar</span>
                  </button>
                  <button
                    onClick={() => { setShowDMPanel(true); setShowFriendsPanel(false); }}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                      showDMPanel ? 'bg-blue-500 text-white' : 'text-neutral-700 hover:bg-blue-50 hover:text-blue-600'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                      showDMPanel ? 'bg-white/20 text-white' : 'bg-neutral-100 group-hover:bg-blue-500 group-hover:text-white'
                    }`}>
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <span className="font-semibold">Direkt Mesajlar</span>
                  </button>
                </div>
              </div>
            </div>

            {/* User Profile Card */}
            <div className="p-4 bg-gradient-to-r from-blue-50 to-blue-100 border-t-2 border-blue-200">
              <div className="flex items-center gap-3 bg-white rounded-2xl p-3 shadow-lg">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold shadow-md">
                  {user?.username?.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-neutral-900 truncate">{user?.username}</div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 bg-green-500 rounded-full shadow-sm"></div>
                    <span className="text-xs text-green-600 font-medium">Çevrimiçi</span>
                  </div>
                </div>
                  <button
                  onClick={() => setShowSettingsModal(true)}
                  className="p-2.5 bg-neutral-100 hover:bg-blue-500 text-neutral-600 hover:text-white rounded-xl transition-all duration-200 hover:scale-110 shadow-sm"
                  title="Ayarlar"
                >
                  <Settings className="w-4 h-4" />
                </button>
            </div>
          </div>
        </div>

          {/* Main Content Area */}
          <div className="flex-1 flex flex-col min-w-0 bg-neutral-50 pb-20 lg:pb-0">
            {showDMPanel ? (
        <div className="flex-1 flex flex-col">
                {/* DM Header with Close Button */}
                <div className="h-16 bg-white border-b-2 border-neutral-200 px-6 flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white shadow-md">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="font-bold text-lg text-neutral-800">Direkt Mesajlar</h2>
                      <p className="text-xs text-neutral-500">Özel sohbetleriniz</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setShowDMPanel(false)}
                    className="p-2 hover:bg-red-50 text-neutral-600 hover:text-red-600 rounded-xl transition-all"
                    title="Kapat"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="flex-1 overflow-hidden">
                  <DirectMessagesView showToast={showToast} />
                </div>
              </div>
            ) : (
              <>
          {/* Channel Header */}
            <div className="h-16 bg-white border-b border-neutral-200 px-6 flex items-center justify-between shadow-sm">
              <div className="flex items-center space-x-3">
            {selectedChannel && (
                  <>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      selectedChannel.type === 'TEXT' 
                        ? 'bg-blue-500' 
                        : 'bg-green-500'
                    } shadow-md`}>
                      {selectedChannel.type === 'TEXT' ? <Hash className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-white" />}
              </div>
                    <div>
                      <span className="font-bold text-neutral-800 text-lg">{selectedChannel.name}</span>
                      <p className="text-xs text-neutral-500">{selectedChannel.type === 'TEXT' ? 'Metin Kanalı' : 'Sesli Kanal'}</p>
                    </div>
                  </>
            )}
          </div>

              <div className="hidden lg:flex items-center gap-2">
                <button onClick={generateInvite} className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-xl transition-all shadow-md hover:shadow-lg flex items-center gap-2">
                  <LinkIcon className="w-4 h-4" />
                  <span className="text-sm font-medium">Davet</span>
                </button>
              </div>
            </div>

            {/* Inline Screen Share (Mesajların Üstünde) */}
            {selectedChannel?.type === 'TEXT' && showTheaterMode && theaterPresenter && (
              <InlineScreenShare
                presenter={theaterPresenter}
                participants={(() => {
                  // Unique participants (duplicate'leri temizle)
                  const uniqueMap = new Map();
                  
                  voiceUsers.forEach(vu => {
                    if (!uniqueMap.has(vu.userId)) {
                      uniqueMap.set(vu.userId, {
                        userId: vu.userId,
                        username: vu.username,
                        isMuted: vu.isMuted,
                        isSpeaking: vu.isSpeaking,
                        isScreenSharing: vu.userId === theaterPresenter.userId,
                        isVideoOn: remoteUsers.find(ru => ru.userId === vu.userId)?.isVideoOn,
                        stream: remoteUsers.find(ru => ru.userId === vu.userId)?.stream,
                      });
                    }
                  });
                  
                  // Add self if not already in list
                  if (!uniqueMap.has(user!.id)) {
                    uniqueMap.set(user!.id, {
                      userId: user!.id,
                      username: user!.username,
                      isMuted,
                      isSpeaking: myAudioLevel > 0.015 && !isMuted,
                      isScreenSharing: isScreenSharing,
                      isVideoOn,
                      stream: isVideoOn ? videoStreamRef.current || undefined : undefined,
                    });
                  }
                  
                  return Array.from(uniqueMap.values());
                })()}
                onClose={() => {
                  setShowTheaterMode(false);
                  setTheaterPresenter(null);
                }}
                myUserId={user!.id}
              />
            )}

            {/* Messages Area - DM Style */}
          {selectedChannel?.type === 'TEXT' ? (
            <>
                <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-neutral-50">
                {loading ? (
                  <div className="flex items-center justify-center h-full">
                      <div className="text-center">
                        <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
                        <p className="text-neutral-500">Yükleniyor...</p>
                      </div>
                  </div>
                ) : messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center text-neutral-500">
                        <div className="w-20 h-20 rounded-3xl bg-blue-100 flex items-center justify-center mx-auto mb-4">
                          <MessageSquare className="w-10 h-10 text-blue-600" />
                        </div>
                        <h3 className="text-xl font-bold text-neutral-800 mb-2">#{selectedChannel.name}</h3>
                        <p className="text-sm">İlk mesajı siz gönderin! 🚀</p>
                    </div>
                  </div>
                ) : (
                    messages.map((msg) => {
                      const isMe = msg.user?.id === user?.id;
                      const inviteMatch = msg.content.match(/https:\/\/app\.asforces\.com\/invite\/([a-zA-Z0-9]+)/);
                      const inviteCode = inviteMatch ? inviteMatch[1] : null;
                      
                      return (
                        <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} px-4 md:px-12 lg:px-24`}>
                          <div className={`max-w-lg ${isMe ? 'order-2' : 'order-1'}`}>
                            {!isMe && (
                              <div className="text-xs text-neutral-500 mb-1 ml-1 font-medium">
                                {msg.user?.displayName || msg.user?.username || 'Kullanıcı'}
                      </div>
                            )}
                            <div className={`inline-block px-4 py-3 rounded-2xl shadow-sm ${
                              isMe 
                                ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-br-md' 
                                : 'bg-white border-2 border-neutral-200 text-neutral-800 rounded-bl-md'
                            }`}>
                              <div className="message-content whitespace-pre-wrap break-words leading-relaxed text-lg">{msg.content}</div>
                              
                              {/* Invite Link Button */}
                              {inviteCode && (
                                <button
                                  onClick={() => {
                                    window.location.href = `/invite/${inviteCode}`;
                                  }}
                                  className={`mt-3 px-4 py-2 rounded-xl font-bold transition-all flex items-center space-x-2 ${
                                    isMe
                                      ? 'bg-blue-800 hover:bg-blue-900 text-white shadow-lg hover:scale-105'
                                      : 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:scale-105'
                                  }`}
                                >
                                  <span>🎉 Sunucuya Katıl</span>
                                </button>
                              )}
                              
                              <div className={`text-xs mt-2 ${isMe ? 'text-blue-200' : 'text-neutral-400'}`}>
                                {new Date(msg.createdAt).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                    </div>
                        </div>
                      );
                    })
                )}
                <div ref={messagesEndRef} />
              </div>

                {/* Message Input - Clean Blue Design */}
                <div className={`p-4 lg:p-6 bg-white border-t border-neutral-200 ${connectedVoiceChannelId ? 'mb-24' : ''}`}>
                  {selectedFile && (
                    <div className="mb-3">
                      <div className="flex items-center gap-3 p-3 bg-blue-50 border-2 border-blue-200 rounded-xl relative overflow-hidden">
                        {/* Progress Bar Background */}
                        {isUploading && uploadProgress > 0 && (
                          <div 
                            className="absolute inset-0 bg-gradient-to-r from-blue-400 to-blue-500 opacity-20 transition-all duration-300"
                            style={{ width: `${uploadProgress}%` }}
                          />
                        )}
                        
                        <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center relative z-10">
                          {isUploading ? (
                            <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          ) : (
                            <span className="text-2xl">📎</span>
                          )}
                        </div>
                        <div className="flex-1 min-w-0 relative z-10">
                          <p className="font-semibold text-neutral-800 truncate">{selectedFile.name}</p>
                          <div className="flex items-center gap-2">
                            <p className="text-xs text-neutral-600">
                              {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                            {isUploading && uploadProgress > 0 && (
                              <span className="text-xs font-bold text-blue-600">
                                %{uploadProgress}
                              </span>
                            )}
                          </div>
                        </div>
                        {!isUploading && (
                          <button
                            onClick={() => setSelectedFile(null)}
                            className="p-2 hover:bg-red-100 text-red-600 rounded-lg transition-all relative z-10"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                  
                  <form onSubmit={sendMessage} className="flex items-center gap-2">
                    {/* Emoji Picker */}
                    <EmojiPicker onEmojiSelect={(emoji) => setNewMessage(prev => prev + emoji)} />
                    
                    {/* File Upload */}
                    <FileUpload 
                      onFileSelect={setSelectedFile}
                      onCancel={() => setSelectedFile(null)}
                      selectedFile={selectedFile}
                    />
                    
                    {/* Message Input */}
                    <div className="flex-1 bg-neutral-50 rounded-2xl border-2 border-neutral-200 focus-within:border-blue-500 focus-within:bg-white transition-all duration-200 shadow-sm">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder={`#${selectedChannel.name} kanalına mesaj gönder...`}
                        className="w-full px-5 py-4 bg-transparent text-neutral-900 placeholder-neutral-500 outline-none font-medium"
                        disabled={isUploading}
                      />
                    </div>
                    
                    {/* Send Button */}
                    <button
                      type="submit"
                      disabled={(!newMessage.trim() && !selectedFile) || isUploading}
                      className="px-6 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed shadow-lg hover:shadow-xl hover:scale-105 font-semibold flex items-center gap-2"
                    >
                      {isUploading ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          <span className="hidden sm:inline">Yükleniyor...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-5 h-5" />
                          <span className="hidden sm:inline">Gönder</span>
                        </>
                      )}
                    </button>
                  </form>
                </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                  <div className="w-24 h-24 rounded-3xl bg-blue-100 flex items-center justify-center mx-auto mb-6">
                    <Volume2 className="w-12 h-12 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-neutral-800 mb-2">Sesli Kanal</h3>
                  <p className="text-neutral-500">Sol menüden sesli kanala katılın</p>
              </div>
            </div>
          )}
          </>
          )}
        </div>

          {/* Right Panel - Members/Friends */}
          {!showFriendsPanel && !showDMPanel ? (
            <div className="hidden xl:flex w-64 bg-white border-l border-neutral-200 flex-col shadow-lg">
              <div className="px-5 py-5 border-b border-neutral-200 bg-blue-50">
                <h3 className="text-sm font-bold text-neutral-700 uppercase tracking-wider flex items-center gap-2">
                  <Users className="w-4 h-4 text-blue-600" />
                  Üyeler — {serverMembers.length}
            </h3>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {serverMembers.map((member) => (
                  <div key={member.userId} className="flex items-center space-x-3 p-3 rounded-xl hover:bg-blue-50 transition-all duration-200 group">
                    <div className="relative">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-md">
                        {member.username?.charAt(0).toUpperCase() || 'U'}
                      </div>
                      {member.isOnline && (
                        <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-green-500 rounded-full border-2 border-white shadow-sm"></div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-neutral-800 truncate text-sm">
                        {member.displayName || member.username}
                      </div>
                      <div className="text-xs text-neutral-500">
                        {member.isOnline ? '🟢 Çevrimiçi' : '⚫ Çevrimdışı'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : showFriendsPanel ? (
            <div className="hidden lg:flex w-[500px] xl:w-[600px] bg-white border-l-2 border-neutral-200 flex-col shadow-2xl">
              <div className="px-6 py-5 border-b-2 border-neutral-200 bg-gradient-to-r from-blue-50 to-blue-100 flex items-center justify-between">
                <h3 className="text-lg font-bold text-neutral-800 flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  Arkadaşlar
                </h3>
                <button onClick={() => setShowFriendsPanel(false)} className="p-2 hover:bg-neutral-200 rounded-xl transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-hidden">
                <FriendsView 
                  onClose={() => setShowFriendsPanel(false)} 
                  showToast={showToast}
                  onOpenDm={(friendId) => {
                    setShowFriendsPanel(false);
                    setShowDMPanel(true);
                  }}
                />
              </div>
            </div>
          ) : null}
          </div>

          {/* Mobile Bottom Navigation */}
          <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 px-2 py-3 flex justify-around shadow-2xl z-50">
            <button onClick={() => { setView('servers'); setShowMobileVoice(false); setShowDMPanel(false); setShowFriendsPanel(false); }} className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-xl transition-all ${view === 'servers' && !showMobileVoice && !showDMPanel ? 'bg-blue-100 text-blue-600' : 'text-neutral-600'}`}>
              <MessageSquare className="w-5 h-5" />
              <span className="text-xs font-medium">Sohbet</span>
            </button>
            <button onClick={() => setShowMobileVoice(!showMobileVoice)} className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-xl transition-all ${showMobileVoice ? 'bg-green-100 text-green-600' : connectedVoiceChannelId ? 'bg-green-50 text-green-600' : 'text-neutral-600'}`}>
              <Volume2 className="w-5 h-5" />
              <span className="text-xs font-medium">Ses</span>
            </button>
            <button onClick={() => { setView('friends'); setShowMobileVoice(false); }} className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-xl transition-all ${view === 'friends' && !showMobileVoice ? 'bg-blue-100 text-blue-600' : 'text-neutral-600'}`}>
              <Users className="w-5 h-5" />
              <span className="text-xs font-medium">Arkadaş</span>
            </button>
            <button onClick={() => { setShowDMPanel(true); setShowMobileVoice(false); setShowFriendsPanel(false); }} className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-xl transition-all ${showDMPanel ? 'bg-blue-100 text-blue-600' : 'text-neutral-600'}`}>
              <MessageSquare className="w-5 h-5" />
              <span className="text-xs font-medium">DM</span>
            </button>
            <button onClick={generateInvite} className="flex flex-col items-center space-y-1 px-3 py-2 rounded-xl text-neutral-600 hover:text-blue-600 transition-all">
              <LinkIcon className="w-5 h-5" />
              <span className="text-xs font-medium">Davet</span>
            </button>
          </div>
          
          {/* Mobile Voice Channels Modal */}
          {showMobileVoice && (
            <div className="lg:hidden fixed inset-0 bg-black/50 z-40 flex items-end" onClick={() => setShowMobileVoice(false)}>
              <div className="w-full bg-white rounded-t-3xl max-h-[80vh] overflow-hidden animate-slide-up" onClick={(e) => e.stopPropagation()}>
                {/* Header */}
                <div className="sticky top-0 bg-gradient-to-r from-green-500 to-green-600 px-6 py-5 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="font-bold text-xl">Sesli Kanallar</h2>
                      <p className="text-xs text-green-100 mt-1">{selectedServer?.name}</p>
                    </div>
                    <button onClick={() => setShowMobileVoice(false)} className="p-2 hover:bg-white/20 rounded-xl transition-all">
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                </div>
                
                {/* Voice Channels List */}
                <div className="overflow-y-auto p-4 space-y-3" style={{ maxHeight: 'calc(80vh - 88px)' }}>
                  {voiceChannels.length === 0 ? (
                    <div className="text-center py-12">
                      <Volume2 className="w-16 h-16 mx-auto text-neutral-300 mb-3" />
                      <p className="text-neutral-500 font-medium">Sesli kanal yok</p>
                    </div>
                  ) : (
                    voiceChannels.map((channel) => {
                      const isConnected = connectedVoiceChannelId === channel.id;
                      const currentChannelUsers = isConnected 
                        ? voiceUsers.map(u => ({ id: u.userId, username: u.username, isMuted: u.isMuted, isSpeaking: u.isSpeaking }))
                        : (channelVoiceUsers[channel.id] || []);
                      
                      return (
                        <div key={channel.id} className="bg-neutral-50 rounded-2xl overflow-hidden border-2 border-neutral-200">
                          <button
                            onClick={() => {
                              if (isConnected) {
                                stopAudioMonitoring();
                                voiceSocketRef.current?.emit('leave-voice');
                                setConnectedVoiceChannelId(null);
                                connectedVoiceChannelIdRef.current = null;
                                setVoiceUsers([]);
                                setShowMobileVoice(false);
                                
                                // 🔊 ÇIKIŞ SESİ ÇAL!
                                if (leaveSoundRef.current) {
                                  leaveSoundRef.current.currentTime = 0;
                                  leaveSoundRef.current.play().catch(e => console.log('Sound play failed:', e));
                                }
                              } else {
                                (async () => {
                                  setConnectedVoiceChannelId(channel.id);
                                  connectedVoiceChannelIdRef.current = channel.id;
                                  
                                  // Mikrofonu başlat ve BEKLE
                                  const success = await startAudioMonitoring();
                                  
                                  if (!success) {
                                    console.error('❌ Mikrofon başlatılamadı');
                                    setConnectedVoiceChannelId(null);
                                    connectedVoiceChannelIdRef.current = null;
                                    return;
                                  }
                                  
                                  // ✅ Mikrofon hazır, sesli kanala katıl
                                  if (voiceSocketRef.current && user && selectedServer) {
                                    voiceSocketRef.current.emit('join-voice', { 
                                      roomId: selectedServer.id,
                                      channelId: channel.id,
                                      userId: user.id,
                                      username: user.username
                                    });
                                    
                                    // 🔊 GİRİŞ SESİ ÇAL! (Mobil)
                                    setTimeout(() => {
                                      if (joinSoundRef.current) {
                                        joinSoundRef.current.currentTime = 0;
                                        joinSoundRef.current.volume = 0.5;
                                        joinSoundRef.current.play().catch(e => console.log('Sound play failed:', e));
                                      }
                                    }, 500);
                                  }
                                  setShowMobileVoice(false);
                                })();
                              }
                            }}
                            className={`w-full flex items-center justify-between px-5 py-4 transition-all ${
                              isConnected
                                ? 'bg-gradient-to-r from-green-500 to-green-600 text-white'
                                : 'bg-white hover:bg-neutral-100'
                            }`}
                          >
                            <div className="flex items-center space-x-3">
                              <Volume2 className={`w-6 h-6 ${isConnected ? 'text-white' : 'text-green-600'}`} />
                              <div className="text-left">
                                <p className={`font-bold text-base ${isConnected ? 'text-white' : 'text-neutral-800'}`}>{channel.name}</p>
                                {currentChannelUsers.length > 0 && (
                                  <p className={`text-xs ${isConnected ? 'text-green-100' : 'text-neutral-500'}`}>
                                    {currentChannelUsers.length} kişi
                                  </p>
                                )}
                              </div>
                            </div>
                            {isConnected && (
                              <div className="flex items-center space-x-2">
                                <span className="text-xs font-medium bg-white/20 px-3 py-1 rounded-full">Bağlı</span>
                                <Phone className="w-5 h-5 text-red-400" />
                              </div>
                            )}
                          </button>
                          
                          {/* Users in channel */}
                          {currentChannelUsers.length > 0 && (
                            <div className="px-4 pb-4 pt-2 space-y-2 bg-white">
                              {currentChannelUsers.map((vu) => {
                                const isMe = vu.id === user?.id;
                                const currentIsSpeaking = isMe ? (myAudioLevel > 0.015 && !isMuted) : vu.isSpeaking;
                
                return (
                  <div 
                                    key={vu.id} 
                                    className={`flex items-center gap-3 px-3 py-2 rounded-xl ${
                                      currentIsSpeaking 
                                        ? 'bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-400' 
                                        : 'bg-neutral-50'
                    }`}
                  >
                    <div className="relative">
                                      <div className={`w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold shadow-lg ${
                                        currentIsSpeaking ? 'ring-4 ring-green-400 ring-offset-2 scale-110' : ''
                                      }`}>
                                        {vu.username?.charAt(0).toUpperCase() || 'U'}
                      </div>
                                      {currentIsSpeaking && (
                                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white animate-ping"></div>
                      )}
                    </div>
                                    
                                    <div className="flex-1">
                                      <div className={`font-bold text-sm ${currentIsSpeaking ? 'text-green-700' : 'text-neutral-800'}`}>
                                        {vu.username} {isMe && <span className="text-xs text-blue-600">(Sen)</span>}
                      </div>
                                      {currentIsSpeaking && (
                                        <div className="flex items-center gap-1 mt-0.5">
                                          <div className="flex gap-0.5">
                                            <div className="w-1 h-2 bg-green-500 rounded-full animate-bounce"></div>
                                            <div className="w-1 h-3 bg-green-500 rounded-full animate-bounce" style={{animationDelay: '100ms'}}></div>
                                            <div className="w-1 h-2 bg-green-500 rounded-full animate-bounce" style={{animationDelay: '200ms'}}></div>
                                          </div>
                                          <span className="text-xs text-green-600 font-medium">Konuşuyor</span>
                            </div>
                          )}
                        </div>
                                    
                                    {isMe && isConnected && (
                                      <div className="flex items-center gap-2">
                                        {/* Mikrofon */}
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setIsMuted(!isMuted);
                                          }}
                                          className={`p-2 rounded-lg ${isMuted ? 'bg-red-100 text-red-600' : 'bg-neutral-100 text-neutral-600'}`}
                                          title={isMuted ? 'Mikrofonu Aç' : 'Mikrofonu Kapat'}
                                        >
                                          {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                                        </button>
                                        
                                        {/* Ekran Paylaşımı */}
                                        <button
                                          onClick={async (e) => {
                                            e.stopPropagation();
                                            if (isScreenSharing) {
                                              handleStopScreenShare();
                                            } else {
                                              try {
                                                const stream = await navigator.mediaDevices.getDisplayMedia({
                                                  video: { cursor: 'always' } as any,
                                                  audio: false,
                                                });
                                                stream.getVideoTracks()[0].onended = () => handleStopScreenShare();
                                                await handleStartScreenShare(stream);
                                              } catch (err) {
                                                showToast('error', 'Ekran paylaşımı reddedildi');
                                              }
                                            }
                                          }}
                                          className={`p-2 rounded-lg ${isScreenSharing ? 'bg-red-100 text-red-600' : 'bg-neutral-100 text-neutral-600'}`}
                                          title={isScreenSharing ? 'Ekran Paylaşımını Durdur' : 'Ekranı Paylaş'}
                                        >
                                          {isScreenSharing ? <MonitorOff className="w-4 h-4" /> : <Monitor className="w-4 h-4" />}
                                        </button>
                                        
                                        {/* Video */}
                                        <button
                                          onClick={async (e) => {
                                            e.stopPropagation();
                                            if (isVideoOn) {
                                              handleStopVideo();
                                            } else {
                                              try {
                                                const stream = await navigator.mediaDevices.getUserMedia({
                                                  video: { width: 1280, height: 720, facingMode: 'user' },
                                                  audio: false,
                                                });
                                                await handleStartVideo(stream);
                                              } catch (err) {
                                                showToast('error', 'Kamera erişimi reddedildi');
                                              }
                                            }
                                          }}
                                          className={`p-2 rounded-lg ${isVideoOn ? 'bg-red-100 text-red-600' : 'bg-neutral-100 text-neutral-600'}`}
                                          title={isVideoOn ? 'Kamerayı Kapat' : 'Kamerayı Aç'}
                                        >
                                          {isVideoOn ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
                                        </button>
                                      </div>
                                    )}
                  </div>
                );
              })}
            </div>
                          )}
          </div>
                      );
                    })
                  )}
        </div>
              </div>
            </div>
          )}
          </>
        )}


      {/* Minimal Sesli Kanal Kontrol Paneli (Modern Compact) */}
      {connectedVoiceChannelId && !showTheaterMode && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
          <div className="bg-neutral-900/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-neutral-700 px-6 py-3 flex items-center gap-4">
            {/* Channel Info */}
            <div className="flex items-center gap-3 border-r border-neutral-700 pr-4">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <div className="text-white">
                <p className="text-sm font-bold">
                  {channels.find(c => c.id === connectedVoiceChannelId)?.name || 'Müzik'}
                </p>
                <p className="text-xs text-neutral-400">{voiceUsers.length} kişi</p>
              </div>
            </div>

            {/* Ekran Paylaşımları (Multi-Presenter Dropdown) */}
            {(remoteUsers.some(u => u.isScreenSharing) || isScreenSharing) && (
              <div className="relative group">
                {(() => {
                  const presenters = [
                    ...(isScreenSharing ? [{ userId: user!.id, username: user!.username + ' (Sen)', stream: screenStreamRef.current || undefined, isScreenSharing: true }] : []),
                    ...remoteUsers.filter(u => u.isScreenSharing)
                  ];
                  const presenterCount = presenters.length;
                  
                  return (
                    <>
                      <button
                        onClick={() => {
                          if (showTheaterMode) {
                            setShowTheaterMode(false);
                            setTheaterPresenter(null);
                          } else if (presenterCount === 1) {
                            const presenter = presenters[0];
                            console.log('🎭 Opening theater for:', presenter.username, 'Stream:', presenter.stream);
                            setTheaterPresenter(presenter);
                            setShowTheaterMode(true);
                          }
                        }}
                        className={`px-4 py-2 rounded-xl font-semibold text-sm transition-all flex items-center gap-2 ${
                          showTheaterMode 
                            ? 'bg-red-500 hover:bg-red-600 text-white' 
                            : 'bg-blue-500 hover:bg-blue-600 text-white animate-pulse'
                        }`}
                      >
                        <Monitor className="w-4 h-4" />
                        {showTheaterMode ? 'Kapat' : 'İzle'}
                        {presenterCount > 1 && <span className="text-xs ml-1">({presenterCount})</span>}
                      </button>
                      
                      {/* Dropdown (Birden fazla paylaşan varsa) */}
                      {presenterCount > 1 && !showTheaterMode && (
                        <div className="absolute bottom-full mb-2 left-0 bg-neutral-800 rounded-xl shadow-2xl border border-neutral-700 py-2 min-w-56 opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity">
                          <div className="px-3 py-1 text-xs text-neutral-400 font-semibold border-b border-neutral-700 mb-1">
                            {presenterCount} Ekran Paylaşımı:
                          </div>
                          {presenters.map(p => (
                            <button
                              key={p.userId}
                              onClick={() => {
                                console.log('🎭 Selected presenter from dropdown:', p.username, 'Stream:', p.stream);
                                setTheaterPresenter(p);
                                setShowTheaterMode(true);
                              }}
                              className="w-full px-4 py-2.5 text-left text-white hover:bg-neutral-700 transition-all flex items-center gap-3"
                            >
                              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-xs font-bold">
                                {p.username.charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <p className="text-sm font-semibold">{p.username}</p>
                                <p className="text-xs text-blue-400 flex items-center gap-1">
                                  <Monitor className="w-3 h-3" />
                                  Ekran paylaşıyor
                                </p>
                              </div>
                            </button>
                          ))}
                        </div>
                      )}
                    </>
                  );
                })()}
              </div>
            )}
            
            {/* Control Buttons */}
            <div className="flex items-center gap-2">
              {/* Mikrofon */}
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-3 rounded-xl transition-all hover:scale-110 ${
                  isMuted ? 'bg-red-500 hover:bg-red-600' : 'bg-neutral-700 hover:bg-neutral-600'
                }`}
                title={isMuted ? 'Mikrofonu Aç' : 'Mikrofonu Kapat'}
              >
                {isMuted ? <MicOff className="w-4 h-4 text-white" /> : <Mic className="w-4 h-4 text-green-400" />}
              </button>
              
              {/* Ekran Paylaşımı (Basit Tek Tık) */}
              <button
                onClick={async (e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  if (isScreenSharing) {
                    handleStopScreenShare();
                  } else {
                    try {
                      const constraints = {
                        video: screenQuality === 'ultra' 
                          ? { cursor: 'always', frameRate: { ideal: 60 }, width: { ideal: 2560 }, height: { ideal: 1440 } }
                          : screenQuality === 'high'
                          ? { cursor: 'always', frameRate: { ideal: 30 }, width: { ideal: 1920 }, height: { ideal: 1080 } }
                          : screenQuality === 'medium'
                          ? { cursor: 'always', frameRate: { ideal: 24 }, width: { ideal: 1920 }, height: { ideal: 1080 } }
                          : { cursor: 'always', frameRate: { ideal: 15 }, width: { ideal: 1280 }, height: { ideal: 720 } },
                        audio: shareSystemAudio ? {
                          echoCancellation: false,
                          noiseSuppression: false,
                          autoGainControl: false,
                          sampleRate: 48000,
                          channelCount: 2
                        } : false
                      } as any;
                      
                      console.log('🎬 Starting screen share - Quality:', screenQuality, 'Audio:', shareSystemAudio);
                      const stream = await navigator.mediaDevices.getDisplayMedia(constraints);
                      
                      if (shareSystemAudio && stream.getAudioTracks().length > 0) {
                        console.log('🔊 System audio track included!');
                        showToast('success', '🖥️🔊 Ekran + Ses paylaşımı başladı');
                      } else {
                        showToast('success', '🖥️ Ekran paylaşımı başladı');
                      }
                      
                      stream.getVideoTracks()[0].onended = () => handleStopScreenShare();
                      await handleStartScreenShare(stream);
                    } catch (err) {
                      showToast('error', 'Ekran paylaşımı reddedildi');
                    }
                  }
                }}
                className={`p-3 rounded-xl transition-all hover:scale-110 ${
                  isScreenSharing ? 'bg-blue-500 hover:bg-blue-600' : 'bg-neutral-700 hover:bg-neutral-600'
                }`}
                title={isScreenSharing ? 'Ekran Paylaşımını Durdur' : 'Ekran Paylaş'}
              >
                {isScreenSharing ? <MonitorOff className="w-4 h-4 text-white" /> : <Monitor className="w-4 h-4 text-neutral-400" />}
              </button>
              
              {/* Ekran Paylaşımı Ayarları */}
              {!isScreenSharing && (
                <div className="relative">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowQualityMenu(!showQualityMenu);
                    }}
                    className="p-3 rounded-xl transition-all hover:scale-110 bg-neutral-700 hover:bg-neutral-600"
                    title="Ekran Paylaşımı Ayarları"
                  >
                    <Settings className="w-4 h-4 text-neutral-400" />
                  </button>
                  
                  {/* Ayarlar Dropdown (İnce ve Yukarı) */}
                  {showQualityMenu && (
                    <>
                      <div className="fixed inset-0 z-[90]" onClick={() => setShowQualityMenu(false)}></div>
                      <div className="absolute bottom-full mb-2 left-0 bg-neutral-900 rounded-xl shadow-2xl border border-neutral-600 w-80 z-[100]" onClick={(e) => e.stopPropagation()}>
                        {/* Header */}
                        <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-4 py-3 rounded-t-xl">
                          <h3 className="text-white font-bold text-sm">Ekran Paylaşımı Ayarları</h3>
                        </div>
                        
                        {/* Content */}
                        <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
                          {/* Sistem Sesi */}
                          <label className="flex items-center gap-2 cursor-pointer p-3 bg-neutral-800 hover:bg-neutral-750 rounded-lg transition-all">
                            <input
                              type="checkbox"
                              checked={shareSystemAudio}
                              onChange={(e) => setShareSystemAudio(e.target.checked)}
                              className="w-4 h-4 rounded accent-blue-500"
                            />
                            <span className="text-lg">🔊</span>
                            <div className="flex-1">
                              <p className="text-white font-semibold text-sm">Sistem Sesi</p>
                              <p className="text-xs text-neutral-400">48kHz Stereo</p>
                            </div>
                          </label>
                          
                          {/* Kalite Seçimi (Compact) */}
                          <div>
                            <p className="text-white font-semibold mb-2 text-sm">Görüntü Kalitesi</p>
                            <div className="space-y-1.5">
                              {[
                                { value: 'low', label: 'Düşük', icon: '📶', res: '720p 15fps' },
                                { value: 'medium', label: 'Orta', icon: '📶📶', res: '1080p 24fps' },
                                { value: 'high', label: 'Yüksek', icon: '📶📶📶', res: '1080p 30fps' },
                                { value: 'ultra', label: 'Ultra', icon: '📶📶📶📶', res: '1440p 60fps' },
                              ].map((option) => (
                                <button
                                  key={option.value}
                                  onClick={() => setScreenQuality(option.value as any)}
                                  className={`w-full px-3 py-2.5 rounded-lg transition-all text-left flex items-center justify-between ${
                                    screenQuality === option.value 
                                      ? 'bg-blue-600 text-white' 
                                      : 'bg-neutral-800 text-white hover:bg-neutral-750'
                                  }`}
                                >
                                  <div className="flex items-center gap-2">
                                    <span>{option.icon}</span>
                                    <div>
                                      <p className="font-semibold text-sm">{option.label}</p>
                                      <p className="text-xs opacity-70">{option.res}</p>
                                    </div>
                                  </div>
                                  {screenQuality === option.value && <span className="text-lg">✓</span>}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        {/* Footer (Compact) */}
                        <div className="px-4 py-3 bg-neutral-800 rounded-b-xl flex items-center justify-between border-t border-neutral-700">
                          <p className="text-xs text-neutral-400">
                            {screenQuality === 'ultra' ? 'Ultra' : screenQuality === 'high' ? 'Yüksek' : screenQuality === 'medium' ? 'Orta' : 'Düşük'}
                            {shareSystemAudio && ' + Ses'}
                          </p>
                          <button
                            onClick={() => setShowQualityMenu(false)}
                            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-sm transition-all"
                          >
                            Kaydet
                          </button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
              
              {/* Video */}
              <button
                onClick={async () => {
                  if (isVideoOn) {
                    handleStopVideo();
                  } else {
                    try {
                      const stream = await navigator.mediaDevices.getUserMedia({
                        video: { width: 1280, height: 720, facingMode: 'user' },
                        audio: false,
                      });
                      await handleStartVideo(stream);
                    } catch (err) {
                      showToast('error', 'Kamera erişimi reddedildi');
                    }
                  }
                }}
                className={`p-3 rounded-xl transition-all hover:scale-110 ${
                  isVideoOn ? 'bg-purple-500 hover:bg-purple-600' : 'bg-neutral-700 hover:bg-neutral-600'
                }`}
                title={isVideoOn ? 'Kamerayı Kapat' : 'Kamerayı Aç'}
              >
                {isVideoOn ? <VideoOff className="w-4 h-4 text-white" /> : <Video className="w-4 h-4 text-neutral-400" />}
              </button>
            </div>
            
            {/* Disconnect (Komple Ayrıl) */}
            <div className="border-l border-neutral-700 pl-4">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  
                  // Sesli kanaldan komple ayrıl
                  if (voiceSocketRef.current && connectedVoiceChannelId) {
                    voiceSocketRef.current.emit('leave-voice');
                  }
                  
                  setConnectedVoiceChannelId(null);
                  connectedVoiceChannelIdRef.current = null;
                  setVoiceUsers([]);
                  setChannelVoiceUsers({});
                  handleStopScreenShare();
                  handleStopVideo();
                  
                  // Audio monitoring durdur
                  if (audioContextRef.current) {
                    audioContextRef.current.close();
                    audioContextRef.current = null;
                  }
                  if (audioLevelIntervalRef.current) {
                    clearInterval(audioLevelIntervalRef.current);
                    audioLevelIntervalRef.current = null;
                  }
                  if (localStreamRef.current) {
                    localStreamRef.current.getTracks().forEach(track => track.stop());
                    localStreamRef.current = null;
                  }
                  
                  // Tüm peer connections'ı temizle
                  peerConnectionsRef.current.forEach(pc => pc.close());
                  peerConnectionsRef.current.clear();
                  
                  showToast('info', '🚪 Sesli kanaldan ayrıldınız');
                }}
                className="p-3 bg-red-500 hover:bg-red-600 rounded-xl transition-all hover:scale-110"
                title="Sesli Kanaldan Tamamen Ayrıl"
              >
                <Phone className="w-4 h-4 text-white rotate-135" />
              </button>
            </div>
          </div>
        </div>
      )}

      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </div>
  );
};

