import { EventEmitter } from 'events';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

/**
 * Oyun bilgisi
 */
export interface GameInfo {
  processName: string;
  displayName: string;
  pid: number;
  windowTitle?: string;
  isFullScreen: boolean;
}

/**
 * Oyun algılama ayarları
 */
export interface GameDetectorConfig {
  enabled: boolean;
  checkInterval: number; // ms - kontrol aralığı
  knownGames: string[]; // Bilinen oyun process isimleri
  autoEnablePTT: boolean; // Oyun algılandığında PTT'yi otomatik aktif et
  fullScreenOnly: boolean; // Sadece tam ekran oyunları algıla
}

/**
 * Bilinen popüler oyunların process isimleri
 */
export const KNOWN_GAMES = [
  // FPS Oyunları
  'csgo.exe',
  'cs2.exe',
  'valorant.exe',
  'valorant-win64-shipping.exe',
  'r5apex.exe', // Apex Legends
  'overwatch.exe',
  'cod.exe',
  'modernwarfare.exe',
  'blackops.exe',
  'rainbowsix.exe',
  'pubg.exe',
  'tslgame.exe', // PUBG
  'fortnite.exe',
  'fortniteclient-win64-shipping.exe',
  
  // MOBA
  'league of legends.exe',
  'dota2.exe',
  
  // MMO/RPG
  'wow.exe',
  'worldofwarcraft.exe',
  'gw2.exe',
  'gw2-64.exe',
  'ff14.exe',
  'ffxiv.exe',
  'ffxiv_dx11.exe',
  'elderscrollsonline.exe',
  'eso64.exe',
  
  // Battle Royale
  'warzone.exe',
  'apexlegends.exe',
  
  // Launcher ve Platformlar
  'steam.exe',
  'epic games launcher',
  'battlenet.exe',
  'origin.exe',
  'uplay.exe',
  'ubisoft game launcher.exe',
  
  // Diğer Popüler Oyunlar
  'minecraft.exe',
  'javaw.exe', // Minecraft
  'gta5.exe',
  'gtav.exe',
  'rdr2.exe',
  'witcher3.exe',
  'cyberpunk2077.exe',
  'eldenring.exe',
  'darksouls3.exe',
  'sekiro.exe',
  
  // Türk Oyunları
  'zula.exe',
  'wolfteam.exe',
  'warface.exe',
  'pointblank.exe',
  'knightonline.exe',
  'metin2.exe',
  'silkroad.exe',
];

/**
 * Oyun Algılama Sınıfı
 * Windows process'lerini izler ve oyun tespit eder
 */
export class GameDetector extends EventEmitter {
  private config: GameDetectorConfig;
  private intervalId: NodeJS.Timeout | null = null;
  private currentGame: GameInfo | null = null;
  private isRunning: boolean = false;
  private lastCheck: number = 0;

  // Varsayılan ayarlar
  static readonly DEFAULT_CONFIG: GameDetectorConfig = {
    enabled: true,
    checkInterval: 5000, // 5 saniye
    knownGames: KNOWN_GAMES,
    autoEnablePTT: true,
    fullScreenOnly: false,
  };

  constructor(config?: Partial<GameDetectorConfig>) {
    super();
    this.config = { ...GameDetector.DEFAULT_CONFIG, ...config };
  }

  /**
   * Algılamayı başlat
   */
  start(): void {
    if (this.isRunning) {
      console.warn('[GameDetector] Already running');
      return;
    }

    this.isRunning = true;
    this.checkForGames(); // İlk kontrolü hemen yap
    
    // Periyodik kontrol
    this.intervalId = setInterval(() => {
      this.checkForGames();
    }, this.config.checkInterval);

    console.log('[GameDetector] Started');
    this.emit('started');
  }

  /**
   * Algılamayı durdur
   */
  stop(): void {
    if (!this.isRunning) {
      return;
    }

    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    this.isRunning = false;
    
    // Mevcut oyun varsa kapat
    if (this.currentGame) {
      this.handleGameClosed(this.currentGame);
      this.currentGame = null;
    }

    console.log('[GameDetector] Stopped');
    this.emit('stopped');
  }

  /**
   * Oyunları kontrol et
   */
  private async checkForGames(): Promise<void> {
    if (!this.config.enabled) {
      return;
    }

    try {
      this.lastCheck = Date.now();
      
      // Windows için process listesi al
      if (process.platform === 'win32') {
        await this.checkWindowsProcesses();
      } else {
        console.log('[GameDetector] Only Windows is supported currently');
      }
    } catch (error) {
      console.error('[GameDetector] Error checking games:', error);
      this.emit('error', error);
    }
  }

  /**
   * Windows process'lerini kontrol et
   */
  private async checkWindowsProcesses(): Promise<void> {
    try {
      // PowerShell ile process listesi ve window bilgisi al
      const command = `
        Get-Process | Where-Object {$_.MainWindowTitle -ne ""} | 
        Select-Object ProcessName, Id, MainWindowTitle, @{Name="IsResponding";Expression={$_.Responding}} | 
        ConvertTo-Json
      `;

      const { stdout } = await execAsync(`powershell -Command "${command}"`, {
        timeout: 3000,
        maxBuffer: 1024 * 1024, // 1MB
      });

      if (!stdout || stdout.trim() === '') {
        // Oyun bulunamadı
        if (this.currentGame) {
          this.handleGameClosed(this.currentGame);
          this.currentGame = null;
        }
        return;
      }

      // JSON parse et
      let processes: any[] = [];
      try {
        const parsed = JSON.parse(stdout);
        processes = Array.isArray(parsed) ? parsed : [parsed];
      } catch (parseError) {
        console.error('[GameDetector] JSON parse error:', parseError);
        return;
      }

      // Oyun ara
      const detectedGame = this.findGameInProcesses(processes);

      // Oyun durumu değişti mi?
      if (detectedGame && !this.currentGame) {
        // Yeni oyun algılandı
        this.currentGame = detectedGame;
        this.handleGameDetected(detectedGame);
      } else if (!detectedGame && this.currentGame) {
        // Oyun kapandı
        this.handleGameClosed(this.currentGame);
        this.currentGame = null;
      } else if (detectedGame && this.currentGame) {
        // Oyun hala çalışıyor, güncelle
        this.currentGame = detectedGame;
      }
    } catch (error) {
      // Sessizce hata yoksay (PowerShell hatası vs.)
      if ((error as any).code !== 'ETIMEDOUT') {
        console.error('[GameDetector] Windows process check error:', error);
      }
    }
  }

  /**
   * Process listesinde oyun ara
   */
  private findGameInProcesses(processes: any[]): GameInfo | null {
    for (const proc of processes) {
      const processName = (proc.ProcessName || '').toLowerCase();
      const windowTitle = proc.MainWindowTitle || '';
      const pid = proc.Id || 0;

      // Bilinen oyunlar listesinde ara
      const isKnownGame = this.config.knownGames.some(gameName => 
        processName.includes(gameName.toLowerCase().replace('.exe', ''))
      );

      if (isKnownGame) {
        // Tam ekran kontrolü (opsiyonel)
        const isFullScreen = this.config.fullScreenOnly 
          ? this.checkIfFullScreen(windowTitle)
          : true;

        if (isFullScreen) {
          // Display name belirle
          const displayName = this.getGameDisplayName(processName);

          return {
            processName: proc.ProcessName,
            displayName,
            pid,
            windowTitle,
            isFullScreen,
          };
        }
      }
    }

    return null;
  }

  /**
   * Tam ekran kontrolü (basit)
   */
  private checkIfFullScreen(windowTitle: string): boolean {
    // Tam ekran tespiti için ek PowerShell komutu gerekir
    // Şimdilik true döndür
    return true;
  }

  /**
   * Process adından görünen isim çıkar
   */
  private getGameDisplayName(processName: string): string {
    // Process adını düzgün isme çevir
    const cleanName = processName
      .replace('.exe', '')
      .replace(/-|_/g, ' ')
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

    // Bilinen oyun isimleri
    const gameNames: { [key: string]: string } = {
      'csgo': 'Counter-Strike: Global Offensive',
      'cs2': 'Counter-Strike 2',
      'valorant': 'VALORANT',
      'r5apex': 'Apex Legends',
      'overwatch': 'Overwatch',
      'cod': 'Call of Duty',
      'rainbowsix': 'Rainbow Six Siege',
      'pubg': 'PLAYERUNKNOWN\'S BATTLEGROUNDS',
      'tslgame': 'PUBG',
      'fortnite': 'Fortnite',
      'league of legends': 'League of Legends',
      'dota2': 'Dota 2',
      'wow': 'World of Warcraft',
      'gw2': 'Guild Wars 2',
      'ff14': 'Final Fantasy XIV',
      'ffxiv': 'Final Fantasy XIV',
      'eso': 'The Elder Scrolls Online',
      'warzone': 'Call of Duty: Warzone',
      'minecraft': 'Minecraft',
      'gta5': 'Grand Theft Auto V',
      'gtav': 'Grand Theft Auto V',
      'rdr2': 'Red Dead Redemption 2',
      'witcher3': 'The Witcher 3',
      'cyberpunk2077': 'Cyberpunk 2077',
      'eldenring': 'Elden Ring',
      'zula': 'Zula',
      'wolfteam': 'Wolfteam',
      'pointblank': 'Point Blank',
      'metin2': 'Metin2',
    };

    const lowerName = processName.toLowerCase().replace('.exe', '');
    return gameNames[lowerName] || cleanName;
  }

  /**
   * Oyun algılandığında
   */
  private handleGameDetected(game: GameInfo): void {
    console.log(`[GameDetector] Game detected: ${game.displayName} (${game.processName})`);
    
    this.emit('gameDetected', game);
    
    if (this.config.autoEnablePTT) {
      this.emit('enablePTT', game);
    }
  }

  /**
   * Oyun kapandığında
   */
  private handleGameClosed(game: GameInfo): void {
    console.log(`[GameDetector] Game closed: ${game.displayName}`);
    
    this.emit('gameClosed', game);
    
    if (this.config.autoEnablePTT) {
      this.emit('disablePTT', game);
    }
  }

  /**
   * Mevcut oyunu al
   */
  getCurrentGame(): GameInfo | null {
    return this.currentGame ? { ...this.currentGame } : null;
  }

  /**
   * Oyun algılandı mı?
   */
  isGameRunning(): boolean {
    return this.currentGame !== null;
  }

  /**
   * Ayarları güncelle
   */
  updateConfig(config: Partial<GameDetectorConfig>): void {
    this.config = { ...this.config, ...config };
    console.log('[GameDetector] Config updated:', this.config);
  }

  /**
   * Ayarları al
   */
  getConfig(): GameDetectorConfig {
    return { ...this.config };
  }

  /**
   * Oyun listesine yeni oyun ekle
   */
  addGame(processName: string): void {
    if (!this.config.knownGames.includes(processName.toLowerCase())) {
      this.config.knownGames.push(processName.toLowerCase());
      console.log(`[GameDetector] Added game: ${processName}`);
    }
  }

  /**
   * Oyun listesinden oyun çıkar
   */
  removeGame(processName: string): void {
    const index = this.config.knownGames.findIndex(
      game => game.toLowerCase() === processName.toLowerCase()
    );
    
    if (index !== -1) {
      this.config.knownGames.splice(index, 1);
      console.log(`[GameDetector] Removed game: ${processName}`);
    }
  }

  /**
   * Manuel oyun kontrolü (hemen)
   */
  async checkNow(): Promise<GameInfo | null> {
    await this.checkForGames();
    return this.getCurrentGame();
  }

  /**
   * Temizleme
   */
  dispose(): void {
    this.stop();
    this.removeAllListeners();
  }
}

