import { app, BrowserWindow, ipcMain, globalShortcut, Tray, Menu, screen } from 'electron';
import { autoUpdater } from 'electron-updater';
import path from 'path';
import { GameDetector, GameInfo } from './GameDetector';

let mainWindow: BrowserWindow | null = null;
let overlayWindow: BrowserWindow | null = null;
let tray: Tray | null = null;
let gameDetector: GameDetector | null = null;

const isDev = process.env.NODE_ENV === 'development';
const WEB_URL = isDev ? 'http://localhost:5173' : 'https://yourdomain.com';

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
    titleBarStyle: 'hidden',
    frame: false,
    backgroundColor: '#1a1a1a',
  });

  mainWindow.loadURL(WEB_URL);

  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Hide to tray instead of closing
  mainWindow.on('close', (event) => {
    if (!app.isQuitting) {
      event.preventDefault();
      mainWindow?.hide();
    }
  });
}

function createTray() {
  tray = new Tray(path.join(__dirname, '../assets/tray-icon.png'));
  
  const contextMenu = Menu.buildFromTemplate([
    {
      label: 'Show App',
      click: () => {
        mainWindow?.show();
      },
    },
    {
      label: 'Quit',
      click: () => {
        app.isQuitting = true;
        app.quit();
      },
    },
  ]);

  tray.setToolTip('AsforceS Voice');
  tray.setContextMenu(contextMenu);
  
  tray.on('click', () => {
    mainWindow?.show();
  });
}

function registerGlobalShortcuts() {
  // Push-to-Talk global shortcut (Ctrl+Space)
  globalShortcut.register('CommandOrControl+Space', () => {
    mainWindow?.webContents.send('ptt-key-press', true);
    overlayWindow?.webContents.send('ptt-key-press', true);
  });

  // Alternatif PTT tuşu (Mouse4 gibi tuşlar için ek handler gerekebilir)
  globalShortcut.register('F1', () => {
    mainWindow?.webContents.send('ptt-key-press', true);
    overlayWindow?.webContents.send('ptt-key-press', true);
  });

  globalShortcut.register('CommandOrControl+M', () => {
    mainWindow?.webContents.send('toggle-mute');
  });
  
  // Overlay toggle
  globalShortcut.register('CommandOrControl+Shift+O', () => {
    toggleOverlay();
  });
}

// Auto-updater
function setupAutoUpdater() {
  autoUpdater.checkForUpdatesAndNotify();

  autoUpdater.on('update-available', () => {
    mainWindow?.webContents.send('update-available');
  });

  autoUpdater.on('update-downloaded', () => {
    mainWindow?.webContents.send('update-downloaded');
  });
}

// Overlay window oluştur (oyun içi gösterim için)
function createOverlay() {
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;
  
  overlayWindow = new BrowserWindow({
    width: 300,
    height: 100,
    x: width - 320,
    y: 20,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    focusable: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  // Overlay HTML içeriği
  overlayWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(`
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body {
          margin: 0;
          padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          background: transparent;
          overflow: hidden;
        }
        .overlay-container {
          background: rgba(0, 0, 0, 0.7);
          backdrop-filter: blur(10px);
          border-radius: 12px;
          padding: 15px 20px;
          color: white;
          display: flex;
          align-items: center;
          gap: 12px;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
        }
        .status-indicator {
          width: 12px;
          height: 12px;
          border-radius: 50%;
          background: #10b981;
          animation: pulse 2s ease-in-out infinite;
        }
        .status-indicator.speaking {
          background: #ef4444;
          animation: pulse-fast 0.5s ease-in-out infinite;
        }
        .game-name {
          font-size: 13px;
          font-weight: 500;
          opacity: 0.9;
        }
        .ptt-status {
          font-size: 11px;
          opacity: 0.7;
          margin-top: 2px;
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        @keyframes pulse-fast {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.2); }
        }
      </style>
    </head>
    <body>
      <div class="overlay-container">
        <div class="status-indicator" id="indicator"></div>
        <div>
          <div class="game-name" id="gameName">AsforceS Voice</div>
          <div class="ptt-status" id="pttStatus">PTT Hazır</div>
        </div>
      </div>
      <script>
        const { ipcRenderer } = require('electron');
        
        ipcRenderer.on('game-detected', (_, game) => {
          document.getElementById('gameName').textContent = game.displayName;
          document.getElementById('pttStatus').textContent = 'Oyun Algılandı';
        });
        
        ipcRenderer.on('game-closed', (_, game) => {
          document.getElementById('gameName').textContent = 'AsforceS Voice';
          document.getElementById('pttStatus').textContent = 'PTT Hazır';
        });
        
        ipcRenderer.on('ptt-key-press', (_, speaking) => {
          const indicator = document.getElementById('indicator');
          const status = document.getElementById('pttStatus');
          
          if (speaking) {
            indicator.classList.add('speaking');
            status.textContent = 'Konuşuyor...';
          } else {
            indicator.classList.remove('speaking');
            status.textContent = 'PTT Hazır';
          }
        });
      </script>
    </body>
    </html>
  `)}`);

  overlayWindow.setIgnoreMouseEvents(true);
  overlayWindow.hide(); // Başlangıçta gizli

  overlayWindow.on('closed', () => {
    overlayWindow = null;
  });
}

function toggleOverlay() {
  if (!overlayWindow) {
    createOverlay();
  }
  
  if (overlayWindow?.isVisible()) {
    overlayWindow.hide();
  } else {
    overlayWindow?.show();
  }
}

// Oyun algılama sistemi
function setupGameDetector() {
  gameDetector = new GameDetector({
    enabled: true,
    checkInterval: 5000,
    autoEnablePTT: true,
    fullScreenOnly: false,
  });

  // Oyun algılandığında
  gameDetector.on('gameDetected', (game: GameInfo) => {
    console.log(`[Main] Game detected: ${game.displayName}`);
    
    // Ana pencereye bildir
    mainWindow?.webContents.send('game-detected', game);
    
    // Overlay'i göster
    if (!overlayWindow) {
      createOverlay();
    }
    overlayWindow?.show();
    overlayWindow?.webContents.send('game-detected', game);
    
    // PTT'yi aktif et
    mainWindow?.webContents.send('enable-ptt', game);
  });

  // Oyun kapandığında
  gameDetector.on('gameClosed', (game: GameInfo) => {
    console.log(`[Main] Game closed: ${game.displayName}`);
    
    // Ana pencereye bildir
    mainWindow?.webContents.send('game-closed', game);
    
    // Overlay'i gizle
    overlayWindow?.hide();
    overlayWindow?.webContents.send('game-closed', game);
  });

  // Hata durumunda
  gameDetector.on('error', (error: Error) => {
    console.error('[Main] GameDetector error:', error);
  });

  // Algılamayı başlat
  gameDetector.start();
}

app.whenReady().then(() => {
  createWindow();
  createTray();
  registerGlobalShortcuts();
  setupGameDetector();
  
  if (!isDev) {
    setupAutoUpdater();
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  
  // GameDetector'ı temizle
  if (gameDetector) {
    gameDetector.dispose();
    gameDetector = null;
  }
});

// IPC handlers
ipcMain.handle('minimize-window', () => {
  mainWindow?.minimize();
});

ipcMain.handle('maximize-window', () => {
  if (mainWindow?.isMaximized()) {
    mainWindow.unmaximize();
  } else {
    mainWindow?.maximize();
  }
});

ipcMain.handle('close-window', () => {
  mainWindow?.hide();
});

ipcMain.handle('quit-app', () => {
  app.isQuitting = true;
  app.quit();
});

// Oyun algılama IPC handlers
ipcMain.handle('get-current-game', () => {
  return gameDetector?.getCurrentGame() || null;
});

ipcMain.handle('check-game-now', async () => {
  return await gameDetector?.checkNow() || null;
});

ipcMain.handle('add-game', (_, processName: string) => {
  gameDetector?.addGame(processName);
});

ipcMain.handle('remove-game', (_, processName: string) => {
  gameDetector?.removeGame(processName);
});

ipcMain.handle('update-game-detector-config', (_, config: any) => {
  gameDetector?.updateConfig(config);
});

ipcMain.handle('get-game-detector-config', () => {
  return gameDetector?.getConfig() || null;
});

// Overlay IPC handlers
ipcMain.handle('show-overlay', () => {
  if (!overlayWindow) {
    createOverlay();
  }
  overlayWindow?.show();
});

ipcMain.handle('hide-overlay', () => {
  overlayWindow?.hide();
});

ipcMain.handle('toggle-overlay', () => {
  toggleOverlay();
});


