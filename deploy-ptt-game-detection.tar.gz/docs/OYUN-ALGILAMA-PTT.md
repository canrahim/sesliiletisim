# Oyun Algılama ve PTT (Push-to-Talk) Sistemi

## 📋 Genel Bakış

AsforceS Voice uygulaması, oyuncular için optimize edilmiş gelişmiş bir ses iletişim sistemi içerir. Bu sistem, oyunları otomatik olarak algılayarak PTT özelliğini aktif hale getirir ve oyun içi overlay ile görsel geri bildirim sağlar.

## ✨ Özellikler

### 1. Otomatik Oyun Algılama
- **Windows Process Monitoring**: Sistem, arka planda çalışan oyunları otomatik olarak algılar
- **Kapsamlı Oyun Listesi**: 50+ popüler oyun (CS:GO, CS2, VALORANT, Apex Legends, LOL, DOTA 2, vb.)
- **Özelleştirilebilir Liste**: Kullanıcılar kendi oyunlarını ekleyebilir
- **Performans Optimizasyonu**: Düşük CPU kullanımı (5 saniye kontrol aralığı)

### 2. Push-to-Talk (PTT)
- **Global Kısayol Tuşları**: 
  - `Ctrl+Space` - Varsayılan PTT
  - `F1` - Alternatif PTT
  - `Ctrl+M` - Mikrofon açma/kapama
  - `Ctrl+Shift+O` - Overlay açma/kapama
- **Özelleştirilebilir Tuş Bağlama**: Herhangi bir tuşu PTT olarak atayabilirsiniz
- **Mouse Button Desteği**: Mouse4, Mouse5 gibi yan tuşlar desteklenir
- **Release Delay**: Tuş bırakıldıktan sonra belirlenen süre transmit devam eder
- **Hold Time**: Minimum basılı tutma süresi

### 3. Voice Activity Detection (VAD)
- **Otomatik Ses Algılama**: Konuşmanızı otomatik algılar
- **Ayarlanabilir Hassasiyet**: 0-100 arası hassasiyet ayarı
- **Hybrid Mod**: PTT + VAD birlikte kullanılabilir
- **Enerji Threshold**: Arka plan gürültüsünü filtreleme

### 4. Oyun İçi Overlay
- **Minimal Tasarım**: Ekranın sağ üst köşesinde küçük bilgi kartı
- **Gerçek Zamanlı Durum**: 
  - Oyun adı görüntülenir
  - PTT durumu (Hazır / Konuşuyor)
  - Görsel gösterge (yeşil/kırmızı nokta)
- **Şeffaf & Blur**: Modern görünüm
- **Mouse İle Etkileşimsiz**: Overlay fare tıklamalarını engelmez

### 5. Web Arayüzü
- **Modern Ayarlar Paneli**: 4 farklı sekme
  - **Profil**: Kullanıcı bilgileri
  - **Ses Cihazları**: Mikrofon ve hoparlör seçimi
  - **PTT & VAD**: Ses ayarları ve PTT yapılandırması
  - **Oyun Algılama**: Oyun listesi yönetimi
- **Canlı Önizleme**: Ayarlar anında uygulanır
- **LocalStorage**: Ayarlar tarayıcıda saklanır

## 🚀 Kurulum ve Kullanım

### Desktop Uygulaması

1. **Uygulamayı Başlatın**
   ```bash
   cd apps/desktop
   npm run dev
   ```

2. **Oyun Algılama Otomatik Başlar**
   - Uygulama açıldığında GameDetector otomatik olarak çalışmaya başlar
   - 5 saniyede bir sistem oyunları kontrol eder

3. **PTT Kullanımı**
   - Sesli kanala katılın
   - `Ctrl+Space` veya ayarladığınız tuşa basılı tutun
   - Konuşun
   - Tuşu bırakın (release delay sonrası transmit durur)

### Web Uygulaması

1. **Ayarlara Gidin**
   - Sağ üst köşeden kullanıcı menüsüne tıklayın
   - "Ayarlar" seçeneğini seçin

2. **PTT Ayarlayın**
   - "PTT & VAD" sekmesine gidin
   - "Push to Talk" seçeneğini aktif edin
   - "Change" butonuna tıklayıp yeni bir tuş atayın
   - Hassasiyet ve diğer ayarları yapın

3. **Oyun Algılama Yapılandırın**
   - "Oyun Algılama" sekmesine gidin
   - "Oyun algılamayı etkinleştir" seçeneğini işaretleyin
   - İsterseniz yeni oyunlar ekleyin

## 🎮 Desteklenen Oyunlar

### FPS Oyunları
- Counter-Strike: Global Offensive (csgo.exe)
- Counter-Strike 2 (cs2.exe)
- VALORANT (valorant.exe)
- Apex Legends (r5apex.exe)
- Overwatch (overwatch.exe)
- Call of Duty serisi
- Rainbow Six Siege (rainbowsix.exe)
- PUBG (pubg.exe, tslgame.exe)
- Fortnite (fortnite.exe)

### MOBA Oyunları
- League of Legends (league of legends.exe)
- Dota 2 (dota2.exe)

### MMO/RPG Oyunları
- World of Warcraft (wow.exe)
- Guild Wars 2 (gw2.exe)
- Final Fantasy XIV (ffxiv.exe)
- The Elder Scrolls Online (eso64.exe)

### Türk Oyunları
- Zula (zula.exe)
- Wolfteam (wolfteam.exe)
- Point Blank (pointblank.exe)
- Metin2 (metin2.exe)
- Knight Online (knightonline.exe)

### Diğer Popüler Oyunlar
- Minecraft (minecraft.exe, javaw.exe)
- GTA V (gta5.exe)
- Red Dead Redemption 2 (rdr2.exe)
- The Witcher 3 (witcher3.exe)
- Cyberpunk 2077 (cyberpunk2077.exe)
- Elden Ring (eldenring.exe)

## ⚙️ Ayarlar

### GameDetector Ayarları

```typescript
interface GameDetectorConfig {
  enabled: boolean;              // Oyun algılamayı aç/kapat
  checkInterval: number;         // Kontrol aralığı (ms) - Varsayılan: 5000
  knownGames: string[];          // Bilinen oyunlar listesi
  autoEnablePTT: boolean;        // Oyun algılandığında PTT'yi aktif et
  fullScreenOnly: boolean;       // Sadece tam ekran oyunları algıla
}
```

### PTT Ayarları

```typescript
interface PTTSettings {
  enabled: boolean;              // PTT'yi aç/kapat
  keybind: PTTKeybind;          // Tuş bağlama
  releaseDelay: number;         // Bırakma gecikmesi (ms) - Varsayılan: 200
  vadEnabled: boolean;          // VAD'ı aç/kapat
  vadSensitivity: number;       // VAD hassasiyeti (0-100) - Varsayılan: 50
  holdTime: number;             // Minimum basılı tutma süresi (ms) - Varsayılan: 100
}
```

### Keybind Formatı

```typescript
interface PTTKeybind {
  key: string;                   // Ana tuş (örn: 'Space', 'F1', 'Mouse4')
  ctrlKey?: boolean;            // Ctrl tuşu
  altKey?: boolean;             // Alt tuşu
  shiftKey?: boolean;           // Shift tuşu
  metaKey?: boolean;            // Windows/Command tuşu
}
```

## 🔧 Teknik Detaylar

### Oyun Algılama Algoritması

1. **PowerShell ile Process Listesi**
   ```powershell
   Get-Process | Where-Object {$_.MainWindowTitle -ne ""} | 
   Select-Object ProcessName, Id, MainWindowTitle, IsResponding | 
   ConvertTo-Json
   ```

2. **Process Name Matching**
   - Büyük/küçük harf duyarsız arama
   - Kısmi eşleşme (csgo, cs2, valorant, vb.)
   - Hızlı lookup için optimizasyon

3. **Performans**
   - Timeout: 3 saniye
   - Buffer: 1MB
   - Minimal CPU kullanımı

### PTT Event Flow

```
Tuş Basıldı → Hold Time Kontrolü → Transmit Başla
    ↓
Konuşma Devam Ediyor
    ↓
Tuş Bırakıldı → Release Delay → Transmit Dur
```

### Overlay Render

```html
<div class="overlay-container">
  <div class="status-indicator" />  <!-- Yeşil/Kırmızı nokta -->
  <div>
    <div class="game-name">Oyun Adı</div>
    <div class="ptt-status">PTT Durumu</div>
  </div>
</div>
```

## 📡 IPC Events

### Desktop → Renderer

- `game-detected` - Oyun algılandı
- `game-closed` - Oyun kapandı
- `ptt-key-press` - PTT tuşuna basıldı
- `enable-ptt` - PTT'yi aktif et
- `toggle-mute` - Mikrofonu aç/kapat

### Renderer → Desktop

- `get-current-game` - Mevcut oyunu al
- `check-game-now` - Hemen kontrol et
- `add-game` - Yeni oyun ekle
- `remove-game` - Oyun çıkar
- `update-game-detector-config` - Ayarları güncelle
- `show-overlay` - Overlay'i göster
- `hide-overlay` - Overlay'i gizle

## 🐛 Sorun Giderme

### Oyun Algılanmıyor

1. **Oyun Listesini Kontrol Edin**
   - Ayarlar → Oyun Algılama → Bilinen Oyunlar
   - Oyununuz listede var mı?

2. **Process Adını Öğrenin**
   - Task Manager'ı açın (Ctrl+Shift+Esc)
   - "Details" sekmesine gidin
   - Oyununuzun .exe dosyasını bulun
   - Ayarlara ekleyin

3. **Yetki Kontrolü**
   - Uygulama yönetici yetkisi olmadan çalışabilir
   - Ancak bazı oyunlar için yönetici yetkisi gerekebilir

### PTT Çalışmıyor

1. **Tuş Bağlamayı Kontrol Edin**
   - Ayarlar → PTT & VAD → Push-to-Talk Key
   - "Change" ile yeni tuş atayın

2. **Global Shortcut Çakışması**
   - Başka bir uygulama aynı tuşu kullanıyor olabilir
   - Farklı bir tuş kombinasyonu deneyin

3. **Mikrofon İzinleri**
   - Tarayıcı/uygulama mikrofon iznine sahip mi?
   - Windows ayarlarından kontrol edin

### Overlay Görünmüyor

1. **Overlay Toggle**
   - `Ctrl+Shift+O` ile açın/kapatın
   - Veya IPC üzerinden kontrol edin

2. **Oyun Algılanmalı**
   - Overlay sadece oyun algılandığında görünür
   - "Oyun Durumu" bölümünü kontrol edin

3. **Always On Top**
   - Overlay "always on top" modunda
   - Tam ekran oyunlarda görünmeyebilir

## 🔮 Gelecek Özellikler

- [ ] Linux ve macOS desteği
- [ ] Profil bazlı ayarlar (oyuna göre farklı PTT ayarları)
- [ ] Sesli aktivite istatistikleri
- [ ] Özelleştirilebilir overlay temaları
- [ ] Foot pedal desteği
- [ ] Joystick button desteği
- [ ] Gelişmiş noise suppression
- [ ] Echo cancellation
- [ ] Auto gain control

## 📞 Destek

Sorunlarınız için:
- GitHub Issues: [AsforcesSesReact/issues](https://github.com/yourusername/AsforcesSesReact/issues)
- Discord: [AsforceS Community](#)
- E-posta: support@asforces.com

## 📄 Lisans

MIT License - Detaylar için `LICENSE` dosyasına bakın.

