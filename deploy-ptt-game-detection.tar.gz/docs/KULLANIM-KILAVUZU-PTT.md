# AsforceS Voice - PTT ve Oyun Algılama Kullanım Kılavuzu

## 🎯 Hızlı Başlangıç

### 1. Desktop Uygulamasını Başlatın

```bash
# Proje dizininde
cd apps/desktop
npm install  # İlk kurulum için
npm run dev  # Geliştirme modu
```

veya

```bash
npm run build  # Production build
```

### 2. Web Uygulamasını Açın

Desktop uygulama otomatik olarak web arayüzünü yükler:
- **Geliştirme:** http://localhost:5173
- **Production:** https://yourdomain.com

## 🎮 Oyun ile Kullanım

### Adım 1: Ayarları Yapılandırın

1. **Uygulamayı Açın**
   - Desktop uygulamayı başlatın
   - Web arayüzü otomatik olarak açılır

2. **Ayarlara Gidin**
   - Sağ üst köşeden kullanıcı ikonuna tıklayın
   - "Ayarlar" seçeneğini seçin

3. **PTT Ayarlarını Yapın**
   - "PTT & VAD" sekmesine gidin
   - ✅ "Push to Talk" seçeneğini işaretleyin
   - "Change" butonuna tıklayın
   - İstediğiniz tuşa basın (örn: `Space`, `F1`, `Mouse4`)
   - Release Delay'i ayarlayın (önerilen: 200ms)

4. **Oyun Algılamayı Aktif Edin**
   - "Oyun Algılama" sekmesine gidin
   - ✅ "Oyun algılamayı etkinleştir"
   - ✅ "Oyun algılandığında PTT'yi otomatik aktif et"
   - Oyununuz listede yoksa ekleyin

### Adım 2: Sesli Kanala Katılın

1. **Sunucu Seçin**
   - Sol taraftan bir sunucu seçin
   - Sesli kanal listesini görün

2. **Sesli Kanala Tıklayın**
   - İstediğiniz sesli kanala tıklayın
   - Bağlantı otomatik olarak başlar

3. **Mikrofon İzni Verin**
   - Tarayıcı mikrofon izni isterse onaylayın
   - Chrome/Edge kullanıyorsanız "Always allow" seçin

### Adım 3: Oyunu Başlatın

1. **Oyununuzu Başlatın**
   - CS:GO, VALORANT, LOL, vb.
   - Oyun tam ekrana alın

2. **Otomatik Algılama**
   - Desktop uygulama oyunu otomatik algılar
   - Sağ üst köşede overlay belirir
   - Overlay şunu gösterir:
     ```
     [🟢] VALORANT
          Oyun Algılandı
     ```

3. **Overlay Kontrolü**
   - `Ctrl+Shift+O` ile overlay'i aç/kapat
   - Overlay her zaman üstte kalır
   - Fare tıklamalarını engellemez

### Adım 4: PTT ile Konuşun

1. **PTT Tuşuna Basın**
   - Ayarladığınız tuşa basılı tutun (örn: `Space`)
   - Overlay kırmızı olur:
     ```
     [🔴] VALORANT
          Konuşuyor...
     ```

2. **Konuşun**
   - Normal bir şekilde konuşun
   - Mikrofon seviyeleri overlay'de görünmez (opsiyonel özellik)

3. **Tuşu Bırakın**
   - Konuşmanız bitince tuşu bırakın
   - Release delay sonrası transmit durur
   - Overlay yeşile döner

## ⚙️ Gelişmiş Ayarlar

### Voice Activity Detection (VAD)

VAD, konuşmanızı otomatik algılar. PTT ile birlikte kullanılabilir.

**Hybrid Mod (Önerilen):**
- PTT + VAD birlikte aktif
- PTT tuşuna bastığınızda transmit başlar
- Konuşmaya devam ettiğiniz sürece transmit devam eder
- Sustuğunuzda otomatik kesilir

**Ayarlama:**
1. Ayarlar → PTT & VAD
2. ✅ "Voice Activity Detection"
3. Sensitivity slider'ı ayarlayın:
   - **0-30:** Çok hassas (arka plan sesleri algılar)
   - **30-70:** Normal (önerilen)
   - **70-100:** Az hassas (sadece yüksek sesler)

### PTT Release Delay

Tuş bırakıldıktan sonra transmit ne kadar devam edecek?

**Öneriler:**
- **0ms:** Anında kes (hızlı konuşmalar için)
- **200ms:** Normal (önerilen)
- **500ms:** Uzun (cümle sonlarını kaçırmaz)
- **1000ms:** Çok uzun (rahat konuşma)

### Hold Time

Tuş ne kadar basılı tutulmalı ki transmit başlasın?

**Öneriler:**
- **0ms:** Anında başla (yanlışlıkla basma riski)
- **100ms:** Normal (önerilen)
- **300ms:** Uzun (yanlış basmaları önler)

### Özel Tuş Kombinasyonları

**Basit Tuşlar:**
- `Space` - Boşluk tuşu
- `F1`, `F2`, ... `F12` - Fonksiyon tuşları
- `CapsLock` - Caps Lock

**Mouse Tuşları:**
- `Mouse4` - Yan tuş (ileri)
- `Mouse5` - Yan tuş (geri)

**Kombinasyonlar:**
- `Ctrl+Space` - Ctrl + Boşluk
- `Alt+F1` - Alt + F1
- `Shift+Mouse4` - Shift + Mouse yan tuş

## 🎨 Overlay Özelleştirme

Overlay şu anda sabit bir tasarıma sahip. Gelecek sürümlerde:
- Konum seçimi (sol üst, sağ üst, vb.)
- Boyut ayarı
- Renk temaları
- Şeffaflık ayarı

## 🔊 Ses Kalitesi Optimizasyonu

### Mikrofon Seçimi

1. Ayarlar → Ses Cihazları
2. Mikrofon dropdown'ından cihazınızı seçin
3. "Test Et" ile kontrol edin

**Öneriler:**
- USB mikrofonlar (Blue Yeti, Rode NT-USB)
- Headset mikrofonlar (HyperX, SteelSeries)
- Laptop mikrofon (son çare)

### Noise Suppression

Tarayıcı/sistem ayarlarından:
- **Windows:** Mikrofon özelliklerinde "Noise Suppression"
- **Chrome:** chrome://flags → "Audio Worklet"

### Echo Cancellation

Otomatik olarak aktif (WebRTC varsayılan)

## 📊 Performans İpuçları

### Düşük CPU Kullanımı

- Oyun algılama: 5 saniye aralıklarla (değiştirilebilir)
- PTT: Event-driven (CPU yükü yok)
- Overlay: Minimal render (GPU accelerated)

### Düşük RAM Kullanımı

- Electron app: ~100MB
- Web renderer: ~50MB
- Toplam: ~150MB

### Network Kullanımı

- Ses codec: Opus (düşük bant genişliği)
- Bitrate: Ayarlanabilir (32-128 kbps)
- Paket boyutu: ~20ms audio frames

## 🐛 Yaygın Sorunlar ve Çözümler

### "Oyun algılanmıyor"

**Neden:**
- Oyun bilinen oyunlar listesinde değil
- Oyun farklı bir process adıyla çalışıyor

**Çözüm:**
1. Task Manager'ı açın (Ctrl+Shift+Esc)
2. "Details" sekmesine gidin
3. Oyununuzun .exe adını bulun
4. Ayarlar → Oyun Algılama → Yeni oyun ekle
5. Process adını girin (örn: mygame.exe)

### "PTT tuşu çalışmıyor"

**Neden:**
- Başka bir uygulama aynı tuşu kullanıyor
- Global shortcut çakışması
- Yönetici yetkisi gerekiyor

**Çözüm:**
1. Farklı bir tuş kombinasyonu deneyin
2. Diğer uygulamaları kapatın
3. Uygulamayı yönetici olarak çalıştırın

### "Overlay görünmüyor"

**Neden:**
- Overlay kapalı
- Oyun algılanmadı
- Tam ekran modu sorunu

**Çözüm:**
1. `Ctrl+Shift+O` ile overlay'i aç
2. Oyun algılandığından emin olun (Ayarlar → Oyun Algılama)
3. Oyunu pencere modunda çalıştırın (geçici test)

### "Ses gecikiyor"

**Neden:**
- Yüksek network latency
- Buffer boyutu çok büyük

**Çözüm:**
1. Internet bağlantınızı kontrol edin
2. Yakın sunuculara bağlanın
3. Kalite ayarlarını düşürün

### "Arka plan sesleri algılanıyor"

**Neden:**
- VAD hassasiyeti çok düşük
- Mikrofon gain çok yüksek

**Çözüm:**
1. VAD sensitivity'yi artırın (50-70 arası)
2. Mikrofon gain'i düşürün
3. Noise gate kullanın
4. Noise canceling mikrofon kullanın

## 📱 Kısayol Tuşları Listesi

### Genel
- `Ctrl+M` - Mikrofonu aç/kapat
- `Ctrl+D` - Deafen (kulağı kapat)
- `Ctrl+Shift+S` - Sesli ayarlar
- `Escape` - Sesli kanaldan ayrıl

### PTT
- `Ctrl+Space` - Varsayılan PTT
- `F1` - Alternatif PTT
- *(Özelleştirilebilir)*

### Overlay
- `Ctrl+Shift+O` - Overlay aç/kapat

### Pencere
- `Ctrl+W` - Pencereyi kapat (tray'e gider)
- `Ctrl+Q` - Uygulamayı kapat

## 🎓 En İyi Pratikler

1. **PTT Tuşu Seçimi**
   - Oyununuzda kullanmadığınız bir tuş seçin
   - Kolay erişilebilir tuş (Space, Caps Lock, Mouse4)
   - Yanlışlıkla basmayacağınız bir tuş

2. **VAD Ayarı**
   - Sessiz bir ortamda test edin
   - Konuşmaya başladığınızda yeşil ışık yanmalı
   - Sustuğunuzda kırmızı olmalı

3. **Overlay Kullanımı**
   - İlk başta açık bırakın
   - Alıştıkça kapatabilirsiniz
   - Önemli anlarda kontrol için açın

4. **Ses Kalitesi**
   - İyi bir mikrofon kullanın
   - Mikrofonu ağzınıza yakın tutun (5-10 cm)
   - Pop filter kullanın (opsiyonel)

5. **Network Optimizasyonu**
   - Kablolu internet kullanın (Wi-Fi yerine)
   - Diğer ağ yüklerini azaltın (indirme, streaming)
   - QoS ayarlarını yapılandırın

## 📞 Destek

Sorunlarınız devam ederse:
- **GitHub Issues:** [AsforcesSesReact/issues](https://github.com/yourusername/AsforcesSesReact/issues)
- **Discord Community:** [AsforceS Discord](#)
- **E-posta:** support@asforces.com

## 🎉 İyi Oyunlar!

AsforceS Voice ile oyun deneyiminiz artık çok daha iyi olacak. İyi eğlenceler!

---

**Güncelleme:** Bu kılavuz AsforceS Voice v2.0 için hazırlanmıştır.

