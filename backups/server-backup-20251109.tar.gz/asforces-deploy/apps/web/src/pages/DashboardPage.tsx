import React from 'react';
import { ModernMainApp } from '../components/app/ModernMainApp';

export const DashboardPage: React.FC = () => {
  return <ModernMainApp />;
};
